import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslationService } from '../../core/services/translation.service';

type SearchPage = 'paid' | 'issued' | 'issuedFiles';

@Component({
  selector: 'app-search-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './search-page.component.html',
  styleUrls: ['./search-page.component.scss']
})
export class SearchPageComponent {
  private readonly pageContent: Record<SearchPage, { translationKey: string; fallback: string }> = {
    paid: { translationKey: 'nav.search.paid', fallback: 'Paid Search' },
    issued: { translationKey: 'nav.search.issued', fallback: 'Issued Search' },
    issuedFiles: { translationKey: 'nav.search.issuedFiles', fallback: 'Issued Files Search' }
  };

  private readonly currentPage: SearchPage;
  protected readonly isAccountMenuOpen = signal(false);
  protected readonly isStatusMenuOpen = signal(false);
  protected readonly isExceptionTypeMenuOpen = signal(false);
  protected readonly selectedAccounts = signal<string[]>([]);
  protected readonly selectedStatuses = signal<string[]>([]);
  protected readonly selectedExceptionTypes = signal<string[]>([]);
  protected readonly statusOptions = [
    { value: 'paid', translationKey: 'search.status.paid', fallback: 'Paid' },
    { value: 'pending', translationKey: 'search.status.pending', fallback: 'Pending' },
    { value: 'return', translationKey: 'search.status.return', fallback: 'Return' },
    { value: 'return-pending', translationKey: 'search.status.returnPending', fallback: 'Return Pending' }
  ];
  protected readonly exceptionTypeOptions = [
    { value: 'amount-mismatch', translationKey: 'search.exceptionType.amountMismatch', fallback: 'Amount Mismatch' },
    { value: 'duplicate-item', translationKey: 'search.exceptionType.duplicateItem', fallback: 'Duplicate Item' },
    { value: 'no-image', translationKey: 'exceptions.noImage', fallback: 'No Image/Poor Quality Image' },
    { value: 'paid-not-issued', translationKey: 'exceptions.paidNotIssued', fallback: 'Paid/Not Issued' },
    { value: 'payee-mismatch', translationKey: 'search.exceptionType.payeeMismatch', fallback: 'Payee Mismatch' },
    { value: 'post-dated', translationKey: 'search.exceptionType.postDated', fallback: 'Post-Dated' },
    { value: 'stale-dated', translationKey: 'search.exceptionType.staleDated', fallback: 'Stale-Dated' },
    { value: 'void-exception', translationKey: 'search.exceptionType.voidException', fallback: 'Void Exception' }
  ];
  protected readonly accountOptions = [
    { name: 'DCS TEST2', transit: '01241 1716238', value: 'DCS TEST2 - 01241 1716238' },
    { name: 'DCS123', transit: '01241 1716299', value: 'DCS123 - 01241 1716299' }
  ];
  protected readonly searchSubmitted = signal(false);

  constructor(
    private readonly route: ActivatedRoute,
    private readonly translationService: TranslationService
  ) {
    const page = this.route.snapshot.data['searchPage'];
    this.currentPage = page === 'issued' || page === 'issuedFiles' ? page : 'paid';
  }

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  protected getPageTitle(): string {
    const content = this.pageContent[this.currentPage];
    return this.t(content.translationKey, content.fallback);
  }

  protected isPaidSearch(): boolean {
    return this.currentPage === 'paid';
  }

  protected toggleAccountMenu(): void {
    this.isAccountMenuOpen.update((isOpen) => !isOpen);
  }

  protected toggleStatusMenu(): void {
    this.isStatusMenuOpen.update((isOpen) => !isOpen);
  }

  protected toggleExceptionTypeMenu(): void {
    this.isExceptionTypeMenuOpen.update((isOpen) => !isOpen);
  }

  protected isStatusSelected(statusValue: string): boolean {
    return this.selectedStatuses().includes(statusValue);
  }

  protected isAllStatusesSelected(): boolean {
    return this.selectedStatuses().length === this.statusOptions.length;
  }

  protected getStatusSelectionLabel(): string {
    const count = this.selectedStatuses().length;
    if (!count) {
      return this.t('search.selectStatus', 'Select Status');
    }

    const key = count === 1 ? 'search.statusSelected' : 'search.statusesSelected';
    const fallback = count === 1 ? '{count} status selected' : '{count} statuses selected';
    return this.t(key, fallback).replace('{count}', String(count));
  }

  protected getSelectedStatusOptions(): typeof this.statusOptions {
    return this.statusOptions.filter((status) => this.selectedStatuses().includes(status.value));
  }

  protected removeStatus(statusValue: string): void {
    this.selectedStatuses.update((selected) => selected.filter((value) => value !== statusValue));
  }

  protected toggleStatus(statusValue: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedStatuses.update((selected) =>
      checked
        ? [...selected, statusValue]
        : selected.filter((value) => value !== statusValue)
    );
  }

  protected toggleAllStatuses(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedStatuses.set(checked ? this.statusOptions.map((status) => status.value) : []);
  }

  protected isExceptionTypeSelected(typeValue: string): boolean {
    return this.selectedExceptionTypes().includes(typeValue);
  }

  protected isAllExceptionTypesSelected(): boolean {
    return this.selectedExceptionTypes().length === this.exceptionTypeOptions.length;
  }

  protected getExceptionTypeSelectionLabel(): string {
    const count = this.selectedExceptionTypes().length;
    if (!count) {
      return this.t('search.selectExceptionTypes', 'Select Exception Type(s)');
    }

    const key = count === 1 ? 'search.exceptionTypeSelected' : 'search.exceptionTypesSelected';
    const fallback = count === 1 ? '{count} exception type selected' : '{count} exception types selected';
    return this.t(key, fallback).replace('{count}', String(count));
  }

  protected getSelectedExceptionTypeOptions(): typeof this.exceptionTypeOptions {
    return this.exceptionTypeOptions.filter((type) => this.selectedExceptionTypes().includes(type.value));
  }

  protected removeExceptionType(typeValue: string): void {
    this.selectedExceptionTypes.update((selected) => selected.filter((value) => value !== typeValue));
  }

  protected toggleExceptionType(typeValue: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedExceptionTypes.update((selected) =>
      checked
        ? [...selected, typeValue]
        : selected.filter((value) => value !== typeValue)
    );
  }

  protected toggleAllExceptionTypes(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedExceptionTypes.set(checked ? this.exceptionTypeOptions.map((type) => type.value) : []);
  }

  protected isAccountSelected(accountValue: string): boolean {
    return this.selectedAccounts().includes(accountValue);
  }

  protected isSelectAllSelected(): boolean {
    return this.selectedAccounts().length === this.accountOptions.length;
  }

  protected toggleAccount(accountValue: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedAccounts.update((selected) =>
      checked
        ? [...selected, accountValue]
        : selected.filter((value) => value !== accountValue)
    );
  }

  protected toggleSelectAll(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedAccounts.set(checked ? this.accountOptions.map((account) => account.value) : []);
  }

  protected search(): void {
    this.searchSubmitted.set(true);
  }

  protected clearSearch(form: HTMLFormElement): void {
    form.reset();
    this.selectedAccounts.set([]);
    this.selectedStatuses.set([]);
    this.selectedExceptionTypes.set([]);
    this.searchSubmitted.set(false);
    this.isAccountMenuOpen.set(false);
    this.isStatusMenuOpen.set(false);
    this.isExceptionTypeMenuOpen.set(false);
  }
}
