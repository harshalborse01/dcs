import { CommonModule } from '@angular/common';
import { Component, computed, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { TranslationService } from '../../core/services/translation.service';

@Component({
  selector: 'app-reports-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './reports-page.component.html',
  styleUrls: ['./reports-page.component.scss']
})
export class ReportsPageComponent {
  protected readonly bannerType = signal<'success' | 'error' | 'none'>('none');
  protected readonly validationMessages = signal<string[]>([]);
  protected readonly bannerRequestNumber = signal('');

  constructor(private readonly translationService: TranslationService) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }
  protected readonly selectedAccounts = signal<string[]>([]);
  protected readonly accountOptions = [
    { name: 'DCS TEST2', transit: '01241 1716238', value: 'DCS TEST2 - 01241 1716238' },
    { name: 'DCS123', transit: '01241 1716299', value: 'DCS123 - 01241 1716299' }
  ];
  protected readonly selectedAccountOptions = computed(() =>
    this.accountOptions.filter((account) => this.selectedAccounts().includes(account.value))
  );
  protected readonly selectedReportType = signal('');
  protected readonly isAccountsDropdownOpen = signal(false);
  protected readonly reportTypesWithoutDateRange = ['Outstanding Issued', 'Stops and Voids', 'Pending Issued'];

  protected toggleAccountsDropdown(): void {
    this.isAccountsDropdownOpen.update((value) => !value);
  }

  protected onReportTypeChange(reportType: string): void {
    this.selectedReportType.set(reportType);
  }

  protected hidesDateRange(reportType: string): boolean {
    return !reportType || this.reportTypesWithoutDateRange.some((type) => type === reportType);
  }

  protected isAccountSelected(accountValue: string): boolean {
    return this.selectedAccounts().includes(accountValue);
  }

  protected isSelectAllSelected(): boolean {
    return this.selectedAccounts().length === this.accountOptions.length;
  }

  protected toggleAccount(accountValue: string, event: Event): void {
    const target = event.target as HTMLInputElement;
    const current = this.selectedAccounts();

    if (target.checked) {
      this.selectedAccounts.set([...current, accountValue]);
      return;
    }

    this.selectedAccounts.set(current.filter((value) => value !== accountValue));
  }

  protected toggleSelectAll(event: Event): void {
    const target = event.target as HTMLInputElement;

    if (target.checked) {
      this.selectedAccounts.set(this.accountOptions.map((account) => account.value));
      return;
    }

    this.selectedAccounts.set([]);
  }

  protected removeAccount(accountValue: string): void {
    this.selectedAccounts.update((selected) => selected.filter((value) => value !== accountValue));
  }

  protected generateReport(reportType: string, dateFrom: string, dateTo: string): void {
    const transit = this.selectedAccounts();

    const missingFields: { key: string; label: string }[] = [];

    if (!transit.length) {
      missingFields.push({ key: 'reportPage.missingTransit', label: this.t('reportsPage.transitAccount', 'Transit/Account') });
    }

    if (!reportType) {
      missingFields.push({ key: 'reportPage.missingReportType', label: this.t('reportsPage.reportType', 'Report Type') });
    }

    if (!this.hidesDateRange(reportType)) {
      if (!dateFrom) {
        missingFields.push({ key: 'reportPage.missingDateFrom', label: this.t('reportsPage.dateFrom', 'Date Range From') });
      }

      if (!dateTo) {
        missingFields.push({ key: 'reportPage.missingTo', label: this.t('reportsPage.to', 'To') });
      }
    }

    if (missingFields.length > 0) {
      this.validationMessages.set(
        missingFields.map((field) => this.t('common.pleaseSelectA', `Please select a ${field.label}.`).replace('{label}', field.label))
      );
      this.bannerType.set('error');
      return;
    }

    const now = new Date();
    const requestNumber = String(Math.floor(1000000 + Math.random() * 9000000)).padStart(7, '0');
    const requestDateTime = `${now.toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric'
    })} ${now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    })} EDT`;

    const generatedEntry = {
      requestNumber,
      requestDateTime,
      customer: 'Demo User',
      account:
        transit.length > 1
          ? 'All or Multiple'
          : this.selectedAccountOptions().map((account) => `${account.name} - ${account.transit}`).join(', '),
      accountTransits: this.selectedAccountOptions().map((account) => account.transit),
      reportType: reportType || 'Unknown Report',
      fileName: `${(reportType || 'report').toLowerCase().replace(/\s+/g, '-')}.xls`,
      requestExpiry: new Date(Date.now() + 86400000).toLocaleDateString('en-US', {
        month: '2-digit',
        day: '2-digit',
        year: 'numeric'
      }),
      status: 'Completed'
    };

    const persistedRows = this.readGeneratedRows();
    const nextRows = [...persistedRows, generatedEntry];
    localStorage.setItem('report-retrieval-generated-rows', JSON.stringify(nextRows));

    this.bannerRequestNumber.set(requestNumber);
    this.selectedAccounts.set([]);
    this.validationMessages.set([]);
    this.bannerType.set('success');
  }

  protected dismissBanner(): void {
    this.bannerType.set('none');
    this.validationMessages.set([]);
  }

  private readGeneratedRows(): Array<Record<string, string>> {
    try {
      const stored = localStorage.getItem('report-retrieval-generated-rows');
      if (!stored) {
        return [];
      }

      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
}
