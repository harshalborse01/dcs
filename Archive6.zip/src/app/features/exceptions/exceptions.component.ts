import { Component, computed, signal } from '@angular/core';
import { TranslationService } from '../../core/services/translation.service';

type ExceptionDisposition = '' | 'pay' | 'return';

type ExceptionRow = {
  serialNumber: string;
  issuedDate: string;
  issuedAmount: string;
  clearingDate: string;
  clearingAmount: string;
  difference: string;
  disposition: ExceptionDisposition;
  returnCode: string;
};

@Component({
  selector: 'app-exceptions',
  standalone: true,
  templateUrl: './exceptions.component.html',
  styleUrls: ['./exceptions.component.scss']
})
export class ExceptionsComponent {
  private readonly returnCodeTranslationKeys: Record<string, string> = {
    'material-alteration': 'exceptions.returnCodes.materialAlteration',
    'post-dated': 'exceptions.returnCodes.postDated',
    'forged-endorsement': 'exceptions.returnCodes.forgedEndorsement',
    'counterfeit-item': 'exceptions.returnCodes.counterfeitItem',
    'intended-payee-not-paid': 'exceptions.returnCodes.intendedPayeeNotPaid',
    'wrong-amount-currency': 'exceptions.returnCodes.wrongAmountCurrency',
    'duplicate-payment': 'exceptions.returnCodes.duplicatePayment',
    'payment-stopped': 'exceptions.returnCodes.paymentStopped',
    'stale-dated': 'exceptions.returnCodes.staleDated'
  };

  protected readonly filtersCollapsed = signal(false);
  protected readonly selectedAccount = signal('all');
  protected readonly reviewMode = signal(false);
  protected readonly reviewNoticeVisible = signal(true);
  protected readonly selectedException = signal<ExceptionRow | null>(null);
  protected readonly showingReverseImage = signal(false);
  protected readonly printDetailsOpen = signal(false);
  private readonly exceptions = signal<ExceptionRow[]>([
    {
      serialNumber: '000000000001',
      issuedDate: '–',
      issuedAmount: '–',
      clearingDate: '10/14/2026',
      clearingAmount: '15.55',
      difference: '–',
      disposition: '',
      returnCode: ''
    },
    {
      serialNumber: '000000000005',
      issuedDate: '–',
      issuedAmount: '–',
      clearingDate: '10/14/2026',
      clearingAmount: '15.55',
      difference: '–',
      disposition: '',
      returnCode: ''
    },
    {
      serialNumber: '000000000012',
      issuedDate: '–',
      issuedAmount: '–',
      clearingDate: '10/14/2026',
      clearingAmount: '15.55',
      difference: '–',
      disposition: '',
      returnCode: ''
    }
  ]);
  protected readonly visibleExceptions = computed(() => {
    const account = this.selectedAccount();
    return account === 'all' || account === 'DCS123' ? this.exceptions() : [];
  });
  protected readonly reviewExceptions = computed(() =>
    this.visibleExceptions().filter((row) => row.returnCode !== '')
  );

  constructor(private readonly translationService: TranslationService) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  protected returnCodeLabel(code: string): string {
    const key = this.returnCodeTranslationKeys[code];
    return key ? this.t(key, code) : code;
  }

  protected selectedCountMessage(): string {
    return this.t('exceptions.selectedCount', 'You have {count} record(s) selected. (Limit 100)')
      .replace('{count}', this.reviewExceptions().length.toString());
  }

  protected toggleFilters(): void {
    this.filtersCollapsed.update((collapsed) => !collapsed);
  }

  protected openReview(): void {
    if (this.reviewExceptions().length > 0) {
      this.reviewNoticeVisible.set(true);
      this.reviewMode.set(true);
    }
  }

  protected dismissReviewNotice(): void {
    this.reviewNoticeVisible.set(false);
  }

  protected backToExceptions(): void {
    this.reviewMode.set(false);
  }

  protected submitReview(): void {
    this.reviewMode.set(false);
  }

  protected openSerialDetails(row: ExceptionRow): void {
    this.showingReverseImage.set(false);
    this.selectedException.set(row);
  }

  protected closeSerialDetails(): void {
    this.printDetailsOpen.set(false);
    this.selectedException.set(null);
  }

  protected openPrintDetails(): void {
    this.printDetailsOpen.set(true);
  }

  protected closePrintDetails(): void {
    this.printDetailsOpen.set(false);
  }

  protected printChequeDetails(): void {
    window.print();
  }

  protected toggleChequeImage(): void {
    this.showingReverseImage.update((showingReverse) => !showingReverse);
  }

  protected setDisposition(serialNumber: string, disposition: ExceptionDisposition): void {
    this.exceptions.update((rows) =>
      rows.map((row) => row.serialNumber === serialNumber
        ? { ...row, disposition, returnCode: disposition === 'return' ? row.returnCode : '' }
        : row)
    );
  }

  protected setReturnCode(serialNumber: string, event: Event): void {
    const select = event.target;
    if (!(select instanceof HTMLSelectElement)) {
      return;
    }

    this.exceptions.update((rows) =>
      rows.map((row) => row.serialNumber === serialNumber ? { ...row, returnCode: select.value } : row)
    );
  }

  protected clearExceptions(): void {
    this.exceptions.update((rows) =>
      rows.map((row) => ({ ...row, disposition: '', returnCode: '' }))
    );
  }
}
