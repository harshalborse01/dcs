import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { TranslationService } from '../../core/services/translation.service';

type ReportRetrievalColumn = {
  key: string;
  label: string;
  sortable?: boolean;
};

type ReportRetrievalRow = {
  requestNumber: string;
  requestDateTime: string;
  customer: string;
  account: string;
  accountTransits?: string[];
  reportType: string;
  fileName: string;
  requestExpiry: string;
  status: string;
};

type SortableColumnKey = 'requestNumber' | 'reportType' | 'status';
type SortDirection = 'asc' | 'desc';

type ReportRetrievalData = {
  title: string;
  note: {
    message: string;
    count: number;
  };
  columns: ReportRetrievalColumn[];
  rows: ReportRetrievalRow[];
  summary: {
    label: string;
    value: string;
    count: string;
  };
};

@Component({
  selector: 'app-report-retrieval',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './report-retrieval.component.html',
  styleUrls: ['./report-retrieval.component.scss']
})
export class ReportRetrievalComponent implements OnInit {
  protected readonly retrievalData = signal<ReportRetrievalData | null>(null);
  protected readonly accountDialogTransits = signal<string[] | null>(null);
  protected readonly sortState = signal<{ key: SortableColumnKey; direction: SortDirection } | null>(null);

  constructor(private readonly translationService: TranslationService) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  protected translateFieldValue(field: string, value: string): string {
    const map: Record<string, Record<string, string>> = {
      status: {
        Completed: 'reportRetrieval.status.completed',
        Pending: 'reportRetrieval.status.pending',
        Ready: 'reportRetrieval.status.ready'
      },
      reportType: {
        Paid: 'reportRetrieval.reportType.paid',
        Stops: 'reportRetrieval.reportType.stops',
        'Stops and Voids': 'reportRetrieval.reportType.stopsAndVoids'
      },
      column: {
        'Request #': 'reportRetrieval.columns.requestNumber',
        'Request Date & Time': 'reportRetrieval.columns.requestDateTime',
        Customer: 'reportRetrieval.columns.customer',
        Account: 'reportRetrieval.columns.account',
        ReportType: 'reportRetrieval.columns.reportType',
        'File Name': 'reportRetrieval.columns.fileName',
        'Request Expiry': 'reportRetrieval.columns.requestExpiry',
        Status: 'reportRetrieval.columns.status'
      }
    };

    const lookup = map[field]?.[value];
    return lookup ? this.t(lookup, value) : value;
  }

  protected getPageTitle(title: string): string {
    return this.t('reportRetrieval.pageTitle', title);
  }

  protected getNoteMessage(message: string): string {
    return this.t('reportRetrieval.note', message);
  }

  protected getColumnLabel(column: ReportRetrievalColumn): string {
    return this.t(
      `reportRetrieval.columns.${column.key}`,
      this.translateFieldValue('column', column.label)
    );
  }

  protected getSummaryLabel(label: string): string {
    return this.t('reportRetrieval.summary.label', label);
  }

  protected sortRows(key: string): void {
    if (key !== 'requestNumber' && key !== 'reportType' && key !== 'status') {
      return;
    }

    this.sortState.update((current) => ({
      key,
      direction: current?.key === key && current.direction === 'asc' ? 'desc' : 'asc'
    }));
  }

  protected getSortedRows(rows: ReportRetrievalRow[]): ReportRetrievalRow[] {
    const sort = this.sortState();
    if (!sort) {
      return rows;
    }

    return [...rows].sort((left, right) => {
      const leftValue = left[sort.key];
      const rightValue = right[sort.key];
      const comparison = leftValue.localeCompare(rightValue, undefined, {
        numeric: sort.key === 'requestNumber',
        sensitivity: 'base'
      });

      return sort.direction === 'asc' ? comparison : -comparison;
    });
  }

  protected getSortArrow(key: string): string {
    const sort = this.sortState();
    if (sort?.key !== key) {
      return '↕';
    }

    return sort.direction === 'asc' ? '▲' : '▼';
  }

  protected getSortAriaLabel(column: ReportRetrievalColumn): string {
    const sort = this.sortState();
    if (sort?.key !== column.key) {
      return `${this.getColumnLabel(column)}: ${this.t('reportRetrieval.sortAscending', 'sort ascending')}`;
    }

    const translationKey = sort.direction === 'asc' ? 'reportRetrieval.sortDescending' : 'reportRetrieval.sortAscending';
    const fallback = sort.direction === 'asc' ? 'sort descending' : 'sort ascending';
    return `${this.getColumnLabel(column)}: ${this.t(translationKey, fallback)}`;
  }

  protected isExcelFile(fileName: string): boolean {
    return fileName.toLowerCase().endsWith('.xls');
  }

  protected openAccountDialog(row: ReportRetrievalRow): void {
    this.accountDialogTransits.set(row.accountTransits ?? []);
  }

  protected closeAccountDialog(): void {
    this.accountDialogTransits.set(null);
  }

  protected downloadReport(row: ReportRetrievalRow): void {
    const fields: Array<[string, string]> = [
      ['Request #', row.requestNumber],
      ['Request Date & Time', row.requestDateTime],
      ['Customer', row.customer],
      ['Account', row.account],
      ['Report Type', row.reportType],
      ['File Name', row.fileName],
      ['Request Expiry', row.requestExpiry],
      ['Status', row.status]
    ];
    const workbook = [
      '<html><head><meta charset="UTF-8"></head><body><table>',
      '<tr><th>Field</th><th>Value</th></tr>',
      ...fields.map(([label, value]) => `<tr><td>${this.escapeHtml(label)}</td><td>${this.escapeHtml(value)}</td></tr>`),
      '</table></body></html>'
    ].join('');
    const file = new Blob([workbook], { type: 'application/vnd.ms-excel;charset=utf-8' });
    const url = URL.createObjectURL(file);
    const link = document.createElement('a');
    link.href = url;
    link.download = row.fileName;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  ngOnInit(): void {
    fetch('/assets/mock-data/reports.json')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Unable to load report mock data');
        }

        return response.json() as Promise<{ reportRetrieval?: ReportRetrievalData }>;
      })
      .then((payload) => {
        const baseData = payload.reportRetrieval ?? null;
        if (!baseData) {
          this.retrievalData.set(null);
          return;
        }

        const generatedRows = this.readGeneratedRows();
        const mergedRows = [...baseData.rows, ...generatedRows];

        this.retrievalData.set({
          ...baseData,
          rows: mergedRows,
          note: {
            ...baseData.note,
            count: mergedRows.length
          },
          summary: {
            ...baseData.summary,
            value: `${mergedRows.length} total`,
            count: String(mergedRows.length)
          }
        });
      })
      .catch((error) => {
        console.error('Failed to load report retrieval data', error);
        this.retrievalData.set(null);
      });
  }

  private readGeneratedRows(): ReportRetrievalRow[] {
    try {
      const stored = localStorage.getItem('report-retrieval-generated-rows');
      if (!stored) {
        return [];
      }

      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  private escapeHtml(value: string): string {
    return value.replace(/[&<>"']/g, (character) => {
      const entities: Record<string, string> = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      };
      return entities[character];
    });
  }
}
