import { Routes } from '@angular/router';
import { ExceptionsComponent } from './features/exceptions/exceptions.component';
import { ContactUsComponent } from './features/contact-us/contact-us.component';
import { HomeComponent } from './features/home/home.component';
import { NotFoundComponent } from './features/not-found/not-found.component';
import { ReportRetrievalComponent } from './features/report-retrieval/report-retrieval.component';
import { ReportsPageComponent } from './features/reports-page/reports-page.component';
import { SearchPageComponent } from './features/search-page/search-page.component';
import { SitemapComponent } from './features/sitemap/sitemap.component';
import { UploadsComponent } from './features/uploads/uploads.component';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'exceptions', component: ExceptionsComponent },
  { path: 'search', redirectTo: 'search/paid', pathMatch: 'full' },
  { path: 'search/paid', component: SearchPageComponent, data: { searchPage: 'paid' } },
  { path: 'search/issued', component: SearchPageComponent, data: { searchPage: 'issued' } },
  { path: 'search/issued-files', component: SearchPageComponent, data: { searchPage: 'issuedFiles' } },
  { path: 'reports', component: ReportsPageComponent },
  { path: 'report-retrieval', component: ReportRetrievalComponent },
  { path: 'uploads', component: UploadsComponent },
  { path: 'sitemap', component: SitemapComponent },
  { path: '**', component: NotFoundComponent }
];
