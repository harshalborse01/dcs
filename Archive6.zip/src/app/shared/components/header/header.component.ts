import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import {
  HeaderData,
  HeaderNavigationItem,
  HeaderSubmenuItem,
  MockDataService
} from '../../../core/services/mock-data.service';
import { SupportedLanguage, TranslationService } from '../../../core/services/translation.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  protected readonly headerData = signal<HeaderData | null>(null);
  protected readonly translationService: TranslationService;

  constructor(
    private readonly mockDataService: MockDataService,
    translationService: TranslationService
  ) {
    this.translationService = translationService;
  }

  ngOnInit(): void {
    this.mockDataService.getHeaderData().subscribe((data) => this.headerData.set(data));
  }

  protected setLanguage(language: SupportedLanguage): void {
    void this.translationService.setLanguage(language);
  }

  protected isLanguage(language: SupportedLanguage): boolean {
    return this.translationService.currentLanguage() === language;
  }

  protected getMenuLabel(item: HeaderNavigationItem): string {
    const lookup: Record<string, string> = {
      '/home': 'nav.home',
      '/exceptions': 'nav.exceptions',
      '/search': 'nav.search',
      '/reports': 'nav.reports',
      '/uploads': 'nav.uploads',
      '/report-retrieval': 'nav.reports.retrieval',
      '/sitemap': 'nav.siteMap'
    };

    return this.translationService.t(lookup[item.route] ?? item.label, item.label);
  }

  protected getSubMenuLabel(item: HeaderSubmenuItem): string {
    const lookup: Record<string, string> = {
      'Paid Search': 'nav.search.paid',
      'Issued Search': 'nav.search.issued',
      'Issued Files Search': 'nav.search.issuedFiles',
      'Customer Reports': 'nav.reports.customer',
      'Report Retrieval': 'nav.reports.retrieval',
      'Add Issued Record': 'nav.uploads.addIssuedRecord',
      'Help': 'header.help',
      'Contact Us': 'header.contact',
      'CPA Information': 'header.cpa',
      'Printer Friendly Format': 'header.print'
    };

    return this.translationService.t(lookup[item.label] ?? item.label, item.label);
  }

  protected getUserIdDisplay(userId: string | undefined): string {
    const value = (userId ?? '').trim();
    if (!value) {
      return '';
    }

    return value.length > 4 ? `${value.slice(0, 4)}...` : value;
  }

  protected getUserInitials(userId: string | undefined): string {
    const value = (userId ?? '').trim();
    if (!value) {
      return '';
    }

    return value.slice(0, 2).toUpperCase();
  }
}
