import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { MockDataService, NotificationMessage, NotificationNotice } from '../../../core/services/mock-data.service';
import { TranslationService } from '../../../core/services/translation.service';

@Component({
  selector: 'app-notification-banner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './notification-banner.component.html',
  styleUrls: ['./notification-banner.component.scss']
})
export class NotificationBannerComponent implements OnInit {
  protected readonly notificationItems = signal<NotificationMessage[]>([]);
  protected readonly notices = signal<NotificationNotice[]>([]);
  private readonly dismissedNoticeIds = signal(new Set<string>());
  protected dismissed = false;

  constructor(
    private readonly mockDataService: MockDataService,
    private readonly translationService: TranslationService
  ) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  protected translateMessage(message: string): string {
    const map: Record<string, string> = {
      'One or more transit/account(s) is inaccessible: 012411716119:, please contact your Administrator.':
        'notification.transitAccount'
    };

    return this.translationService.t(map[message] ?? message, message);
  }

  ngOnInit(): void {
    this.mockDataService.getNotifications().subscribe((data) => {
      this.notificationItems.set(data.items);
      this.notices.set(data.notices);
    });
  }

  dismiss(): void {
    this.dismissed = true;
  }

  isNoticeDismissed(id: string): boolean {
    return this.dismissedNoticeIds().has(id);
  }

  dismissNotice(id: string): void {
    this.dismissedNoticeIds.update((dismissed) => new Set(dismissed).add(id));
  }
}
