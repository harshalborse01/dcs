# BMO-Style Angular Portal

This project recreates the BMO-inspired banking portal layout shown in the provided reference screenshot using Angular 21, standalone components, local mock data, and responsive styling.

## Prerequisites

- Node.js 20+
- npm 10+

## Install dependencies

```bash
npm install
```

## Run locally

```bash
npm start -- --host 0.0.0.0 --port 4200
```

Then open http://localhost:4200 in your browser.

## Production build

```bash
npx ng build --configuration production --progress=false
```

## Key folders

- `src/app/core/services` — local mock-data access
- `src/app/shared/components` — reusable shell components
- `src/app/features` — Home, Search, Reports, Site Map, and Not Found pages
- `src/assets/mock-data` — JSON mock content
- `src/assets/images` — local logo asset

## Notes

- No external APIs are used.
- All navigation and banner data come from local JSON files.
- Styling follows a reusable CSS custom-property design system inspired by the reference.
