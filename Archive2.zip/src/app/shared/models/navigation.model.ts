export interface NavigationItem {
  label: string;
  route: string;
  icon?: string | null;
  hasDropdown?: boolean;
}
