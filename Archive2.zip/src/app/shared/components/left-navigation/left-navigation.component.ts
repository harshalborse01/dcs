import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MockDataService, NavigationCardItem } from '../../../core/services/mock-data.service';

@Component({
  selector: 'app-left-navigation',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './left-navigation.component.html',
  styleUrls: ['./left-navigation.component.scss']
})
export class LeftNavigationComponent implements OnInit {
  protected readonly navigationItems = signal<NavigationCardItem[]>([]);

  constructor(private readonly mockDataService: MockDataService) {}

  ngOnInit(): void {
    this.mockDataService.getNavigationCards().subscribe((items) => this.navigationItems.set(items));
  }
}
