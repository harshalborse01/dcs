import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { NotificationBannerComponent } from '../notification-banner/notification-banner.component';

@Component({
  selector: 'app-main-content',
  standalone: true,
  imports: [CommonModule, NotificationBannerComponent],
  templateUrl: './main-content.component.html',
  styleUrls: ['./main-content.component.scss']
})
export class MainContentComponent {
  @Input() pageType: 'home' | 'search' | 'reports' | 'sitemap' = 'home';
}
