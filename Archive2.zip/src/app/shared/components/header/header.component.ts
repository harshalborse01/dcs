import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { HeaderData, MockDataService } from '../../../core/services/mock-data.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  protected readonly headerData = signal<HeaderData | null>(null);

  constructor(private readonly mockDataService: MockDataService) {}

  ngOnInit(): void {
    this.mockDataService.getHeaderData().subscribe((data) => this.headerData.set(data));
  }

  protected getUserIdDisplay(userId: string | undefined): string {
    const value = (userId ?? '').trim();
    if (!value) {
      return '';
    }

    return value.length > 4 ? `${value.slice(0, 4)}...` : value;
  }

  protected getUserInitials(userId: string | undefined): string {
    const value = (userId ?? '').trim();
    if (!value) {
      return '';
    }

    return value.slice(0, 2).toUpperCase();
  }
}
