import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { MockDataService, NotificationMessage } from '../../../core/services/mock-data.service';

@Component({
  selector: 'app-notification-banner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './notification-banner.component.html',
  styleUrls: ['./notification-banner.component.scss']
})
export class NotificationBannerComponent implements OnInit {
  protected readonly notificationItems = signal<NotificationMessage[]>([]);
  protected dismissed = false;

  constructor(private readonly mockDataService: MockDataService) {}

  ngOnInit(): void {
    this.mockDataService.getNotifications().subscribe((data) => this.notificationItems.set(data.items));
  }

  dismiss(): void {
    this.dismissed = true;
  }
}
