import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-sitemap',
  standalone: true,
  imports: [RouterLink],
  template: `
    <section class="page-panel sitemap-page">
      <h1>Site Map</h1>
      <nav class="sitemap-links" aria-label="Site map navigation">
        <a routerLink="/home">Home</a>
        <a routerLink="/search">Search</a>
        <a routerLink="/reports">Reports</a>
        <a routerLink="/sitemap">Site Map</a>
      </nav>
    </section>
  `,
  styles: `
    :host { display:block; }
    .sitemap-page { padding: 2rem 2.25rem; }
    .sitemap-page h1 { margin: 0 0 1.5rem; font-size: clamp(2rem, 2vw, 2.5rem); color: var(--color-text); }
    .sitemap-links { display:flex; flex-direction:column; gap:1rem; }
    .sitemap-links a { color: var(--color-primary); font-size:1.3rem; text-decoration:none; }
    .sitemap-links a:hover { text-decoration:underline; }
  `
})
export class SitemapComponent {}
