import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { MockDataService, ReportItem } from '../../core/services/mock-data.service';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section class="page-panel reports-page">
      <h1>Reports</h1>
      @if (reports().length) {
        <div class="reports-list">
          @for (report of reports(); track report.id) {
            <article class="report-item">
              <h2>{{ report.title }}</h2>
              <div class="meta-row">
                <span>{{ report.period }}</span>
                <span class="status-badge">{{ report.status }}</span>
              </div>
            </article>
          }
        </div>
      } @else {
        <div class="empty-state">No reports are available.</div>
      }
    </section>
  `,
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {
  protected readonly reports = signal<ReportItem[]>([]);

  constructor(private readonly mockDataService: MockDataService) {}

  ngOnInit(): void {
    this.mockDataService.getReports().subscribe((items) => this.reports.set(items));
  }
}
