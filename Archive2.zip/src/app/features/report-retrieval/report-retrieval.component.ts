import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';

type ReportRetrievalColumn = {
  key: string;
  label: string;
  sortable?: boolean;
};

type ReportRetrievalRow = {
  requestNumber: string;
  requestDateTime: string;
  customer: string;
  account: string;
  reportType: string;
  fileName: string;
  requestExpiry: string;
  status: string;
};

type ReportRetrievalData = {
  title: string;
  note: {
    message: string;
    count: number;
  };
  columns: ReportRetrievalColumn[];
  rows: ReportRetrievalRow[];
  summary: {
    label: string;
    value: string;
    count: string;
  };
};

@Component({
  selector: 'app-report-retrieval',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (retrievalData(); as data) {
      <section class="report-retrieval-page">
        <h1>{{ data.title }}</h1>

        <div class="alert-box" aria-label="Report retrieval note">
          <div class="alert-icon">i</div>
          <div class="alert-content">
            <div class="alert-text">{{ data.note.message }}</div>
          </div>
          <button type="button" class="alert-close" aria-label="Close">×</button>
        </div>

        <div class="table-panel">
          <div class="table-header">
            @for (column of data.columns; track column.key) {
              <div class="header-cell" [class.sortable]="column.sortable">
                {{ column.label }}
                @if (column.sortable) {
                  <span class="sort-arrow">▼</span>
                }
              </div>
            }
          </div>

          <div class="table-body">
            @for (row of data.rows; track row.requestNumber) {
              <div class="table-row">
                <div class="cell request-number">{{ row.requestNumber }}</div>
                <div class="cell">{{ row.requestDateTime }}</div>
                <div class="cell">{{ row.customer }}</div>
                <div class="cell">{{ row.account }}</div>
                <div class="cell report-type">{{ row.reportType }}</div>
                <div class="cell file-name">{{ row.fileName }}</div>
                <div class="cell">{{ row.requestExpiry }}</div>
                <div class="cell status-cell">{{ row.status }}</div>
              </div>
            }
          </div>

          <div class="refresh-row">
            <button type="button" class="refresh-button">refresh</button>
          </div>
      

          <div class="table-footer">
            <div class="summary-text">{{ data.summary.label }} {{ data.summary.value }}</div>
            <div class="pager-box">
              <button type="button" class="pager-button" aria-label="Previous page">◀</button>
              <span class="pager-label">Page</span>
              <span class="pager-page">1</span>
              <span class="pager-label">of 1</span>
              <button type="button" class="pager-button" aria-label="Next page">▶</button>
            </div>
          </div>

          
        </div>
      </section>
    }
  `,
  styles: `
    :host {
      display: block;
      width: 100%;
    }

    .report-retrieval-page {
      width: 100%;
      min-height: 100%;
      padding-top: 0.2rem;
      color: #1d2023;
      background: transparent;
    }

    h1 {
      margin: 0 0 1.2rem;
      color: #000;
      font-size: 24px;
      font-weight: 700;
      letter-spacing: -0.04em;
    }

    .alert-box {
      display: grid;
      grid-template-columns: 2.1rem minmax(0, 1fr) auto 2.4rem;
      align-items: start;
      gap: 0.85rem;
      width: min(100%, 560px);
      margin-left: auto;
      margin-bottom: 1rem;
      background: var(--color-notification);
      color: var(--color-white);
      padding: 0.85rem 0.9rem 0.9rem 0.55rem;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
      border-radius: 0;
    }

    .alert-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 1.5rem;
      height: 1.5rem;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.18);
      color: var(--color-white);
      font-weight: 700;
      font-size: 0.92rem;
      margin-top: 0.1rem;
    }

    .alert-content {
      display: flex;
      flex-direction: column;
      gap: 0.15rem;
      min-width: 0;
    }

    .alert-text {
      margin: 0;
      color: var(--color-white);
      font-size: 0.9rem;
      line-height: 1.45;
      word-break: break-word;
    }

    .alert-badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 1.4rem;
      height: 1.4rem;
      padding: 0.1rem 0.35rem;
      border-radius: 50%;
      background: #d4493a;
      color: #fff;
      font-size: 0.75rem;
      font-weight: 700;
      flex-shrink: 0;
      justify-self: center;
      align-self: center;
    }

    .alert-close {
      align-self: flex-start;
      justify-self: end;
      border: 0;
      background: transparent;
      color: var(--color-white);
      font-size: 1.6rem;
      line-height: 1;
      cursor: pointer;
      padding: 0;
    }

    .table-panel {
      border: 1px solid rgba(0, 0, 0, 0.12);
      background: rgba(255, 255, 255, 0.02);
      overflow: hidden;
    }

    .table-header,
    .table-row {
      display: grid;
      grid-template-columns: minmax(72px, 0.9fr) minmax(150px, 1.5fr) minmax(90px, 1fr) minmax(110px, 1.2fr) minmax(100px, 1.1fr) minmax(175px, 2fr) minmax(110px, 1.1fr) minmax(95px, 0.9fr);
      align-items: center;
      min-width: 1100px;
    }

    .table-header {
      background: rgba(255, 255, 255, 0.18);
      border-bottom: 2px solid #1ea3d9;
      min-height: 58px;
    }

    .header-cell {
      padding: 0.8rem 0.7rem;
      font-size: 0.82rem;
      font-weight: 700;
      color: #1f2327;
      text-align: left;
      white-space: nowrap;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .sortable {
      position: relative;
    }

    .sort-arrow {
      font-size: 0.62rem;
      margin-left: 0.35rem;
      color: #0c8cc1;
      vertical-align: middle;
    }

    .table-body {
      background: rgba(255, 255, 255, 0.08);
    }

    .table-row {
      min-height: 56px;
      border-bottom: 1px solid rgba(0, 0, 0, 0.08);
    }

    .table-row:last-child {
      border-bottom: none;
    }

    .cell {
      padding: 0.8rem 0.7rem;
      font-size: 0.76rem;
      color: #2b2d30;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .cell:last-child {
      border-right: none;
    }

    .request-number {
      color: #1d2a31;
      font-weight: 600;
    }

    .report-type {
      
    }

    .file-name {
      color: #0b6f9d;
      text-decoration: underline;
      font-weight: 500;
    }

    .status-cell {
      
    }

    .table-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-height: 56px;
      border-top: 1px solid rgba(0, 0, 0, 0.08);
      padding: 0 1rem;
    }

    .summary-text {
      font-size: 0.84rem;
      font-weight: 600;
      white-space: nowrap;
    }

    .pager-box {
      display: flex;
      align-items: center;
      gap: 0.45rem;
      font-size: 0.76rem;
      font-weight: 600;
    }

    .pager-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 1.7rem;
      height: 1.7rem;
      border: 1px solid rgba(0, 0, 0, 0.7);
      background: rgba(255, 255, 255, 0.09);
      cursor: pointer;
    }

    .pager-page {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 1.2rem;
      height: 1.5rem;
      padding: 0 0.4rem;
      border: 1px solid rgba(0, 0, 0, 0.7);
      background: rgba(255, 255, 255, 0.12);
      font-weight: 700;
    }

    .refresh-row {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 0.6rem;
      background: #1fa3d7;
      padding: 0.6rem 0.9rem 0.9rem 0;
    }

    .refresh-count {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 1.55rem;
      height: 1.55rem;
      border-radius: 50%;
      background: #e74c3c;
      color: #fff;
      font-size: 0.72rem;
      font-weight: 700;
    }

    .refresh-button {
      min-width: 4.5rem;
      height: 2rem;
      border: 1px solid rgba(0, 0, 0, 0.2);
      background: rgba(255, 255, 255, 0.35);
      color: #0e2d3a;
      font-weight: 600;
      cursor: pointer;
    }

    @media (max-width: 1180px) {
      .table-panel {
        overflow-x: auto;
      }
    }
  `
})
export class ReportRetrievalComponent implements OnInit {
  protected readonly retrievalData = signal<ReportRetrievalData | null>(null);

  ngOnInit(): void {
    fetch('/assets/mock-data/reports.json')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Unable to load report mock data');
        }

        return response.json() as Promise<{ reportRetrieval?: ReportRetrievalData }>;
      })
      .then((payload) => {
        const baseData = payload.reportRetrieval ?? null;
        if (!baseData) {
          this.retrievalData.set(null);
          return;
        }

        const generatedRows = this.readGeneratedRows();
        const mergedRows = [...baseData.rows, ...generatedRows];

        this.retrievalData.set({
          ...baseData,
          rows: mergedRows,
          note: {
            ...baseData.note,
            count: mergedRows.length
          },
          summary: {
            ...baseData.summary,
            value: `${mergedRows.length} total`,
            count: String(mergedRows.length)
          }
        });
      })
      .catch((error) => {
        console.error('Failed to load report retrieval data', error);
        this.retrievalData.set(null);
      });
  }

  private readGeneratedRows(): ReportRetrievalRow[] {
    try {
      const stored = localStorage.getItem('report-retrieval-generated-rows');
      if (!stored) {
        return [];
      }

      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
}
