import { Component } from '@angular/core';

@Component({
  selector: 'app-not-found',
  standalone: true,
  template: `
    <section class="page-panel not-found-page">
      <h1>Page Not Found</h1>
      <p>The page you requested could not be found.</p>
    </section>
  `,
  styles: `
    :host { display:block; }
    .not-found-page { padding: 2rem 2.25rem; }
    h1 { margin: 0 0 0.75rem; color: var(--color-text); }
    p { color: var(--color-text-secondary); }
  `
})
export class NotFoundComponent {}
