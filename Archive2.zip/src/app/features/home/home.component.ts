import { Component } from '@angular/core';
import { MainContentComponent } from '../../shared/components/main-content/main-content.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [MainContentComponent],
  template: `
    <app-main-content pageType="home"></app-main-content>
  `
})
export class HomeComponent {}
