import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MockDataService, SearchRecord } from '../../core/services/mock-data.service';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="page-panel search-page">
      <h1>Search</h1>
      <div class="search-box" role="search">
        <input
          type="text"
          [(ngModel)]="query"
          placeholder="Search records"
          aria-label="Search records"
        />
        <button type="button" (click)="applyFilter()">Search</button>
      </div>

      @if (filteredRecords().length) {
        <div class="results-card">
          @for (record of filteredRecords(); track record.id) {
            <article class="record-item">
              <h3>{{ record.title }}</h3>
              <p>{{ record.category }}</p>
              <span>{{ record.description }}</span>
            </article>
          }
        </div>
      } @else {
        <div class="empty-state">No records match your search.</div>
      }
    </section>
  `,
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  protected query = '';
  protected readonly records = signal<SearchRecord[]>([]);
  protected readonly filteredRecords = signal<SearchRecord[]>([]);

  constructor(private readonly mockDataService: MockDataService) {}

  ngOnInit(): void {
    this.mockDataService.getSearchResults().subscribe((records) => {
      this.records.set(records);
      this.filteredRecords.set(records);
    });
  }

  applyFilter(): void {
    const value = this.query.trim().toLowerCase();
    const nextRecords = value
      ? this.records().filter((record) =>
          `${record.title} ${record.category} ${record.description}`.toLowerCase().includes(value)
        )
      : this.records();

    this.filteredRecords.set(nextRecords);
  }
}
