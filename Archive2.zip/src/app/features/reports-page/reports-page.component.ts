import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-reports-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section class="reports-page">
      <h1>Generate Customer Reports</h1>

      @if (bannerType() !== 'none') {
        <aside class="notification-banner" [class.error]="bannerType() === 'error'" aria-live="polite">
          <div class="banner-icon" aria-hidden="true">i</div>
          <div class="banner-content">
            @if (bannerType() === 'error') {
              @for (message of validationMessages(); track message) {
                <p>{{ message }}</p>
              }
            } @else {
              <p>Your report has been generated successfully.</p>
            }
          </div>
          <button class="dismiss-button" type="button" aria-label="Dismiss notification" (click)="dismissBanner()">
            ×
          </button>
        </aside>
      }

      <form class="customer-report-form" aria-label="Generate Customer Reports form">
        <div class="field-group">
          <label>Customer:</label>
          <input type="text" value="Demo User" aria-label="Customer" readonly />
        </div>

        <div class="field-group">
          <label>Transit/Account:</label>
          <div class="account-dropdown" [class.open]="isAccountsDropdownOpen()" aria-label="Transit Account">
            <button type="button" class="account-dropdown-toggle" (click)="toggleAccountsDropdown()">
              <span>{{ selectedAccounts().length ? selectedAccounts().join(', ') : 'Select Accounts' }}</span>
            </button>

            <div class="account-dropdown-menu">
              @for (account of accountOptions; track account.value) {
                <label class="checkbox-row">
                  <input
                    type="checkbox"
                    [checked]="isAccountSelected(account.value)"
                    (change)="toggleAccount(account.value, $event)"
                    aria-label="{{ account.label }}"
                  />
                  <span>{{ account.label }}</span>
                </label>
              }

              <label class="checkbox-row select-all-row">
                <input
                  type="checkbox"
                  [checked]="isSelectAllSelected()"
                  (change)="toggleSelectAll($event)"
                  aria-label="Select all accounts"
                />
                <span>Select All</span>
              </label>
            </div>
          </div>
        </div>

        <div class="field-group report-type-group">
          <label>Report Type:</label>
          <select class="report-type-select" aria-label="Report Type">
            <option selected>Please select</option>
            <option>Outstanding and Paid</option>
            <option>Outstanding Issued</option>
            <option>Stops and Voids</option>
            <option>Item Trace</option>
            <option>Paid</option>
            <option>Adjustments</option>
            <option>Return</option>
            <option>Deleted</option>
            <option>Positive Pay Serial Corrected</option>
            <option>Exception</option>
            <option>Item Audit Log</option>
            <option>Account and Customer Audit Log</option>
            <option>Pending Issued</option>
          </select>
        </div>

        <div class="field-group date-field-group">
          <label>Date Range From:</label>
          <div class="date-wrap">
            <input type="date" value="2026-10-12" aria-label="Date range from" />
          </div>
        </div>

        <div class="field-group to-field">
          <label>To:</label>
          <div class="date-wrap">
            <input type="date" value="2026-10-12" aria-label="Date range to" />
          </div>
        </div>

        <button type="button" class="generate-button" (click)="generateReport()">Generate Report</button>
      </form>
    </section>
  `,
  styles: `
    :host {
      display: block;
      width: 100%;
      min-height: 100%;
    }

    .notification-banner {
      display: grid;
      grid-template-columns: 2.1rem minmax(0, 1fr) 2.4rem;
      align-items: start;
      gap: 0.85rem;
      width: min(100%, 560px);
      margin-left: auto;
      margin-bottom: 1rem;
      background: var(--color-notification);
      color: var(--color-white);
      padding: 0.85rem 0.9rem 0.9rem 0.55rem;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
      border-radius: 0;
      z-index: 1;
    }

    .notification-banner.error {
      background: #d33b3b;
    }

    .banner-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 1.5rem;
      height: 1.5rem;
      border-radius: 50%;
      background: rgba(255,255,255,0.18);
      font-weight: 700;
      font-size: 0.92rem;
      margin-top: 0.1rem;
    }

    .banner-content {
      display: flex;
      flex-direction: column;
      gap: 0.15rem;
    }

    .banner-content p {
      margin: 0;
      color: var(--color-white);
      font-size: 0.9rem;
      line-height: 1.45;
      word-break: break-word;
    }

    .dismiss-button {
      align-self: flex-start;
      justify-self: end;
      background: transparent;
      border: 0;
      color: var(--color-white);
      font-size: 1.6rem;
      line-height: 1;
      cursor: pointer;
      padding: 0;
    }

    .reports-page {
      min-height: 100%;
      padding-top: 0.45rem;
      background: transparent;
    }

    h1 {
      margin: 0 0 1.2rem;
      color: #000;
  font-size: 24px;
  font-weight: 700;
      letter-spacing: -0.04em;
    }

    .customer-report-form {
      width: min(100%, 330px);
      max-height: 77vh !important;
    padding: 30px 20px;
    border: 1px solid var(--color-border);
    }

    .field-group {
      display: flex;
      flex-direction: column;
      gap: 0.32rem;
      margin-bottom: 0.8rem;
    }

    .field-group label {
      color: rgba(60, 65, 70, 0.9);
      font-size: 0.72rem;
      font-weight: 500;
      line-height: 1.25;
      letter-spacing: 0.01em;
    }

    input,
    select {
      width: 100%;
      height: 2rem;
      border: 1px solid rgba(138, 145, 150, 0.82);
      border-radius: 3px;
      background: rgba(255, 255, 255, 0.08);
      color: rgba(41, 46, 50, 0.85);
      font-size: 0.75rem;
      padding: 0.35rem 0.75rem;
      box-sizing: border-box;
      outline: none;
    }

    input:focus,
    select:focus {
      border-color: rgba(0, 121, 184, 0.8);
      box-shadow: 0 0 0 2px rgba(0, 121, 184, 0.12);
    }

    input[readonly],
    input:disabled {
      background: rgba(235, 238, 240, 0.9);
      color: rgba(72, 78, 83, 0.9);
      cursor: not-allowed;
      opacity: 1;
    }

    select {
      appearance: none;
      background-image: linear-gradient(45deg, transparent 50%, rgba(80, 85, 90, 0.85) 50%),
        linear-gradient(135deg, rgba(80, 85, 90, 0.85) 50%, transparent 50%);
      background-position: calc(100% - 16px) calc(50% - 2px), calc(100% - 11px) calc(50% - 2px);
      background-size: 5px 5px, 5px 5px;
      background-repeat: no-repeat;
      padding-right: 2rem;
    }

    .report-type-select {
      height: 2.2rem;
      border-width: 2px;
      border-color: rgba(72, 80, 87, 0.9);
      background-color: rgba(255, 255, 255, 0.05);
      font-size: 0.78rem;
    }

    .account-dropdown {
      position: relative;
    }

    .account-dropdown-toggle {
      width: 100%;
      height: 2rem;
      border: 1px solid rgba(138, 145, 150, 0.82);
      border-radius: 3px;
      background: rgba(255, 255, 255, 0.08);
      color: rgba(41, 46, 50, 0.85);
      font-size: 0.75rem;
      padding: 0.35rem 2rem 0.35rem 0.75rem;
      text-align: left;
      cursor: pointer;
      position: relative;
    }

    .account-dropdown-toggle::after {
      content: '▾';
      position: absolute;
      right: 0.8rem;
      top: 50%;
      transform: translateY(-50%);
      font-size: 0.8rem;
      color: rgba(60, 65, 70, 0.9);
    }

    .account-dropdown-menu {
      display: none;
      position: absolute;
      top: calc(100% + 0.25rem);
      left: 0;
      right: 0;
      background: #fff;
      border: 1px solid rgba(138, 145, 150, 0.82);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
      z-index: 10;
      padding: 0.45rem 0.55rem;
      max-height: 220px;
      overflow-y: auto;
    }

    .account-dropdown.open .account-dropdown-menu {
      display: flex;
      flex-direction: column;
      gap: 0.35rem;
    }

    .checkbox-row {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: rgba(41, 46, 50, 0.85);
      font-size: 0.75rem;
      line-height: 1.2;
      cursor: pointer;
      padding: 0.1rem 0;
    }

    .checkbox-row input {
      width: 0.9rem;
      height: 0.9rem;
      margin: 0;
      accent-color: #0ea7d9;
      flex-shrink: 0;
    }

    .select-all-row {
      padding-top: 0.35rem;
      border-top: 1px solid rgba(138, 145, 150, 0.45);
      margin-top: 0.1rem;
      font-weight: 600;
    }

    .date-wrap {
      position: relative;
    }

    .date-wrap input {
      padding-right: 1.9rem;
      color: rgba(51, 58, 62, 0.9);
    }

    input[type='date'] {
      appearance: none;
      -webkit-appearance: none;
      min-height: 2rem;
      position: relative;
    }

    input[type='date']::-webkit-calendar-picker-indicator {
      opacity: 1;
      cursor: pointer;
      filter: invert(0.45);
      width: 14px;
      height: 14px;
      margin-right: -4px;
    }

    .to-field {
      margin-top: 0.3rem;
    }

    .generate-button {
      width: 100%;
      height: 2.35rem;
      margin-top: 0.4rem;
      border: 0;
      border-radius: 4px;
      background: #0ea7d9;
      color: #fff;
      font-size: 0.74rem;
      font-weight: 600;
      letter-spacing: 0.01em;
      cursor: pointer;
      box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.12);
    }

    .generate-button:hover,
    .generate-button:focus-visible {
      filter: brightness(0.98);
      outline: none;
    }

    @media (max-width: 700px) {
      .customer-report-form {
        width: 100%;
      }
    }
  `
})
export class ReportsPageComponent {
  protected readonly bannerType = signal<'success' | 'error' | 'none'>('none');
  protected readonly validationMessages = signal<string[]>([]);
  protected readonly selectedAccounts = signal<string[]>([]);
  protected readonly isAccountsDropdownOpen = signal(false);
  protected readonly accountOptions = [
    { label: 'Account 001', value: 'Account 001' },
    { label: 'Account 002', value: 'Account 002' },
    { label: 'Account 003', value: 'Account 003' }
  ];

  protected toggleAccountsDropdown(): void {
    this.isAccountsDropdownOpen.update((value) => !value);
  }

  protected isAccountSelected(accountValue: string): boolean {
    return this.selectedAccounts().includes(accountValue);
  }

  protected isSelectAllSelected(): boolean {
    return this.selectedAccounts().length === this.accountOptions.length;
  }

  protected toggleAccount(accountValue: string, event: Event): void {
    const target = event.target as HTMLInputElement;
    const current = this.selectedAccounts();

    if (target.checked) {
      this.selectedAccounts.set([...current, accountValue]);
      return;
    }

    this.selectedAccounts.set(current.filter((value) => value !== accountValue));
  }

  protected toggleSelectAll(event: Event): void {
    const target = event.target as HTMLInputElement;

    if (target.checked) {
      this.selectedAccounts.set(this.accountOptions.map((account) => account.value));
      return;
    }

    this.selectedAccounts.set([]);
  }

  protected generateReport(): void {
    const transit = this.selectedAccounts();
    const reportType = (document.querySelector('[aria-label="Report Type"]') as HTMLSelectElement | null)?.value ?? '';
    const dateFrom = (document.querySelector('[aria-label="Date range from"]') as HTMLInputElement | null)?.value ?? '';
    const dateTo = (document.querySelector('[aria-label="Date range to"]') as HTMLInputElement | null)?.value ?? '';

    const missingFields: { label: string }[] = [];

    if (!transit.length) {
      missingFields.push({ label: 'Transit/Account' });
    }

    if (!reportType || reportType === 'Please select') {
      missingFields.push({ label: 'Report Type' });
    }

    if (!dateFrom) {
      missingFields.push({ label: 'Date Range From' });
    }

    if (!dateTo) {
      missingFields.push({ label: 'To' });
    }

    if (missingFields.length > 0) {
      this.validationMessages.set(
        missingFields.map((field) => `Please select a ${field.label}.`)
      );
      this.bannerType.set('error');
      return;
    }

    const now = new Date();
    const requestNumber = String(Math.floor(1000000 + Math.random() * 9000000)).padStart(7, '0');
    const requestDateTime = `${now.toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric'
    })} ${now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    })} EDT`;

    const generatedEntry = {
      requestNumber,
      requestDateTime,
      customer: 'Demo User',
      account: transit.length ? transit.join(', ') : 'All Accounts',
      reportType: reportType || 'Unknown Report',
      fileName: `${(reportType || 'report').toLowerCase().replace(/\s+/g, '-')}.csv`,
      requestExpiry: new Date(Date.now() + 86400000).toLocaleDateString('en-US', {
        month: '2-digit',
        day: '2-digit',
        year: 'numeric'
      }),
      status: 'Completed'
    };

    const persistedRows = this.readGeneratedRows();
    const nextRows = [...persistedRows, generatedEntry];
    localStorage.setItem('report-retrieval-generated-rows', JSON.stringify(nextRows));

    this.selectedAccounts.set([]);
    this.validationMessages.set([]);
    this.bannerType.set('success');
  }

  protected dismissBanner(): void {
    this.bannerType.set('none');
    this.validationMessages.set([]);
  }

  private readGeneratedRows(): Array<Record<string, string>> {
    try {
      const stored = localStorage.getItem('report-retrieval-generated-rows');
      if (!stored) {
        return [];
      }

      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
}
