import { Component } from '@angular/core';

@Component({
  selector: 'app-exceptions',
  standalone: true,
  template: `
    <section class="page-panel empty-page">
      <h1>Exceptions</h1>
    </section>
  `,
  styles: `
    :host { display: block; }
    .empty-page {
      min-height: 180px;
      max-width: 820px;
    }
    h1 {
      color: var(--color-primary);
      margin: 0;
      font-size: 2rem;
      font-weight: 500;
    }
  `
})
export class ExceptionsComponent {}
