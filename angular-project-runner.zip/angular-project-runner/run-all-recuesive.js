
const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const readline = require("readline");

const rootDir = __dirname;
const START_DELAY_MS = 5000;

const EXCLUDED_DIRS = new Set([
    "node_modules",
    ".git",
    ".svn",
    ".hg",
    "dist",
    "build",
    "coverage",
    ".angular",
    ".next",
    ".cache"
]);

// Recursively find Angular projects
function findProjects(directory, found = []) {
    let entries;

    try {
        entries = fs.readdirSync(directory, {
            withFileTypes: true
        });
    } catch (error) {
        console.warn(`Cannot access: ${directory}`);
        return found;
    }

    const packagePath = path.join(directory, "package.json");

    if (fs.existsSync(packagePath)) {
        try {
            const pkg = JSON.parse(
                fs.readFileSync(packagePath, "utf8")
            );

            if (pkg.scripts && pkg.scripts.start) {
                found.push({
                    name: path.basename(directory),
                    path: directory,
                    relativePath: path.relative(rootDir, directory)
                });
            }
        } catch (error) {
            console.log(`Invalid package.json: ${packagePath}`);
        }
    }

    for (const entry of entries) {
        if (!entry.isDirectory()) continue;
        if (EXCLUDED_DIRS.has(entry.name)) continue;
        if (entry.name.startsWith(".")) continue;

        findProjects(
            path.join(directory, entry.name),
            found
        );
    }

    return found;
}

const projects = findProjects(rootDir);

const processes = [];
let selectedProjects = [];
let currentIndex = 0;
let shuttingDown = false;
let launchTimer;

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Display available projects
function showProjects() {
    console.log("\n========== ANGULAR PROJECTS ==========\n");

    projects.forEach((project, index) => {
        console.log(`${index + 1}. ${project.name}`);
        console.log(`   Path: ${project.relativePath}\n`);
    });

    console.log("Enter project numbers separated by commas.");
    console.log("Example: 1,3,4");
    console.log("Enter ALL to run all projects.");
    console.log("Enter 0 to exit.\n");

    rl.question("Select projects: ", answer => {
        const input = answer.trim();

        if (input === "0") {
            rl.close();
            return;
        }

        if (input.toUpperCase() === "ALL") {
            selectedProjects = [...projects];
        } else {
            const numbers = input.split(",").map(n => n.trim());

            const invalid = numbers.some(n =>
                !/^\d+$/.test(n) ||
                Number(n) < 1 ||
                Number(n) > projects.length
            );

            if (invalid || numbers.length === 0) {
                console.log("\nInvalid selection. Try again.\n");
                showProjects();
                return;
            }

            selectedProjects = [
                ...new Set(numbers.map(Number))
            ].map(n => projects[n - 1]);
        }

        if (selectedProjects.length === 0) {
            console.log("No projects selected.");
            rl.close();
            return;
        }

        console.log("\nSelected projects:");

        selectedProjects.forEach(project => {
            console.log(`- ${project.relativePath}`);
        });

        rl.close();
        startNextProject();
    });
}

// Start projects one by one
function startNextProject() {
    if (shuttingDown) return;

    if (currentIndex >= selectedProjects.length) {
        console.log("\nAll selected projects launched!");
        console.log("All projects are running simultaneously.");
        console.log("Press Ctrl+C to stop all projects.");
        return;
    }

    const project = selectedProjects[currentIndex];

    console.log("\n======================================");
    console.log(`Starting: ${project.name}`);
    console.log(`Location: ${project.relativePath}`);
    console.log("======================================\n");

    const npmCommand =
        process.platform === "win32" ? "npm.cmd" : "npm";

    const child = spawn(
        npmCommand,
        ["start"],
        {
            cwd: project.path,
            stdio: "inherit",
            shell: process.platform === "win32"
        }
    );

    processes.push({
        project,
        child
    });

    child.on("error", error => {
        console.error(
            `Failed to start ${project.name}:`,
            error.message
        );
    });

    child.on("exit", (code, signal) => {
        if (!shuttingDown) {
            console.log(
                `\n${project.name} stopped. Exit code: ${code}`
            );
        }
    });

    currentIndex++;

    if (currentIndex < selectedProjects.length) {
        launchTimer = setTimeout(
            startNextProject,
            START_DELAY_MS
        );
    } else {
        console.log("\nAll selected projects launched!");
    }
}

// Stop all projects
function stopAll() {
    if (shuttingDown) return;

    shuttingDown = true;

    if (launchTimer) {
        clearTimeout(launchTimer);
    }

    console.log("\nStopping all Angular projects...");

    processes.forEach(({ project, child }) => {
        if (child.exitCode === null && !child.killed) {
            console.log(`Stopping ${project.name}`);
            child.kill("SIGTERM");
        }
    });

    setTimeout(() => process.exit(0), 1000);
}

process.on("SIGINT", stopAll);
process.on("SIGTERM", stopAll);

// Application entry point
if (projects.length === 0) {
    console.log("No Angular projects found!");
    console.log(
        "Place run-all.js in the common parent folder."
    );
    rl.close();
} else {
    console.log(`Found ${projects.length} Angular projects.`);
    showProjects();
}
