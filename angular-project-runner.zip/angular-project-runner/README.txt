# Angular Project Runner

This folder contains `run-all.js`, a Node.js helper that lets you choose which
Angular projects to start.

## Folder layout

Place `run-all.js` in the parent folder that contains your Angular project
folders:

    AngularProjects/
    ├── run-all.js
    ├── DigitalChequeService/
    │   └── package.json
    ├── CustomerService/
    │   └── package.json
    └── PaymentService/
        └── package.json

The runner detects immediate subfolders that contain a `package.json` with a
`scripts.start` command.

## Requirements

- Node.js and npm installed.
- Dependencies installed in each selected project (`npm install`, if needed).
- Each project's `package.json` must define its own `scripts.start`, for example:

      "scripts": {
        "start": "ng serve --port 4300"
      }

The runner executes `npm start` inside each selected project, so each project
uses its own configured port and other start options.

## Run

Open a terminal in the parent folder and execute:

    node run-all.js

Choose projects by number, separated by commas (example: `1,3`), enter `ALL`
to start all detected projects, or `0` to exit.

Projects are launched one after another, five seconds apart, and remain running
simultaneously. Press Ctrl+C in the runner terminal to stop the started
processes.

## Notes

- Detection is one folder level deep; nested project folders are not scanned.
- The five-second interval is a launch delay, not a readiness check.
- If two projects use the same port, one may fail to start. Give each project
  a unique port in its own `package.json` start script.
- The runner does not install dependencies automatically.
