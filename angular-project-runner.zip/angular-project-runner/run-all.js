const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const readline = require("readline");

const rootDir = __dirname;
const START_DELAY_MS = 5000;

// Find immediate child folders containing a package.json with an npm start script.
function findProjects() {
    return fs.readdirSync(rootDir, { withFileTypes: true })
        .filter(entry => entry.isDirectory())
        .filter(entry => {
            const packagePath = path.join(rootDir, entry.name, "package.json");
            if (!fs.existsSync(packagePath)) return false;

            try {
                const pkg = JSON.parse(fs.readFileSync(packagePath, "utf8"));
                return Boolean(pkg.scripts && pkg.scripts.start);
            } catch (error) {
                console.warn(`Skipping ${entry.name}: invalid package.json`);
                return false;
            }
        })
        .map(entry => entry.name);
}

const projects = findProjects();
const runningProcesses = [];
let selectedProjects = [];
let currentIndex = 0;
let shuttingDown = false;

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function promptForProjects() {
    console.log("\nAvailable Angular projects:\n");
    projects.forEach((project, index) => {
        console.log(`${index + 1}. ${project}`);
    });

    console.log("\nEnter project numbers separated by commas (e.g. 1,3,4).");
    console.log("Enter ALL to run every detected project, or 0 to exit.\n");

    rl.question("Select projects: ", answer => {
        const selection = answer.trim();

        if (selection === "0") {
            rl.close();
            return;
        }

        if (selection.toUpperCase() === "ALL") {
            selectedProjects = [...projects];
        } else {
            const numbers = selection.split(",").map(value => value.trim());

            const invalid = numbers.some(value =>
                !/^\d+$/.test(value) ||
                Number(value) < 1 ||
                Number(value) > projects.length
            );

            if (invalid || numbers.length === 0) {
                console.log("Invalid selection. Please try again.");
                promptForProjects();
                return;
            }

            selectedProjects = [...new Set(numbers.map(Number))]
                .map(number => projects[number - 1]);
        }

        if (selectedProjects.length === 0) {
            console.log("No projects selected.");
            rl.close();
            return;
        }

        console.log("\nSelected projects:");
        selectedProjects.forEach(project => console.log(` - ${project}`));
        rl.close();

        startNextProject();
    });
}

function startNextProject() {
    if (shuttingDown) return;

    if (currentIndex >= selectedProjects.length) {
        console.log("\nAll selected projects have been launched.");
        console.log("They will keep running until you press Ctrl+C.");
        return;
    }

    const project = selectedProjects[currentIndex];
    const projectPath = path.join(rootDir, project);

    console.log(`\n[${currentIndex + 1}/${selectedProjects.length}] Starting ${project}`);
    console.log("Using the project's own npm start script and configured port.");

    // Use npm.cmd on Windows; npm on macOS/Linux.
    const npmCommand = process.platform === "win32" ? "npm.cmd" : "npm";

    const child = spawn(npmCommand, ["start"], {
        cwd: projectPath,
        stdio: "inherit",
        shell: process.platform === "win32"
    });

    runningProcesses.push({ project, child });

    child.on("error", error => {
        console.error(`Could not start ${project}: ${error.message}`);
    });

    child.on("exit", (code, signal) => {
        if (!shuttingDown) {
            console.log(`\n${project} exited (code: ${code}, signal: ${signal || "none"}).`);
        }
    });

    currentIndex++;

    if (currentIndex < selectedProjects.length) {
        setTimeout(startNextProject, START_DELAY_MS);
    } else {
        console.log("\nAll selected projects have been launched.");
        console.log("Press Ctrl+C to stop the runner and its child processes.");
    }
}

function stopAll() {
    if (shuttingDown) return;
    shuttingDown = true;

    console.log("\nStopping started projects...");

    for (const { project, child } of runningProcesses) {
        if (child.exitCode === null && !child.killed) {
            console.log(`Stopping ${project}...`);
            child.kill("SIGTERM");
        }
    }

    setTimeout(() => process.exit(0), 1000);
}

process.on("SIGINT", stopAll);
process.on("SIGTERM", stopAll);

if (projects.length === 0) {
    console.log("No projects found.");
    console.log("Place this runner file beside your project folders.");
    console.log("Each project must contain package.json with a scripts.start command.");
    rl.close();
} else {
    promptForProjects();
}
