const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const readline = require("readline");

// EDIT THESE PROJECT ENTRIES.
// Use absolute paths. Forward slashes are recommended on Windows.
const projects = [
    {
        name: "DigitalChequeService",
        path: "D:/Projects/ui/DigitalChequeService",
        command: "npm start",
        enabled: true
    },
    {
        name: "AdminPortal",
        path: "D:/Projects/Admin/AdminPortal",
        command: "npm run start -- --port 4301",
        enabled: true
    },
    {
        name: "PaymentService",
        path: "E:/Applications/PaymentService",
        command: "ng serve --port 4400",
        enabled: true
    },
    {
        name: "CustomerService",
        path: "D:/OldProjects/CustomerService",
        command: "npm run dev",
        enabled: false
    }
];

const START_DELAY_MS = 5000;

const enabledProjects = projects.filter(p => p.enabled);
const running = [];
let selected = [];
let index = 0;
let stopping = false;
let timer;

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function showMenu() {
    console.log("\\n========== CONFIGURED PROJECTS ==========\\n");

    enabledProjects.forEach((p, i) => {
        console.log(`${i + 1}. ${p.name}`);
        console.log(`   Folder : ${p.path}`);
        console.log(`   Command: ${p.command}\\n`);
    });

    if (!enabledProjects.length) {
        console.log("No enabled projects. Set enabled: true in run-all.js.");
        rl.close();
        return;
    }

    console.log("Enter numbers separated by commas (example: 1,3).");
    console.log("Enter ALL to launch all enabled projects, or 0 to exit.\\n");

    rl.question("Select projects: ", answer => {
        const value = answer.trim();

        if (value === "0") {
            rl.close();
            return;
        }

        if (value.toUpperCase() === "ALL") {
            selected = [...enabledProjects];
        } else {
            const parts = value.split(",").map(v => v.trim());
            const invalid = parts.some(v =>
                !/^\\d+$/.test(v) ||
                Number(v) < 1 ||
                Number(v) > enabledProjects.length
            );

            if (invalid || parts.length === 0) {
                console.log("\\nInvalid selection. Try again.\\n");
                showMenu();
                return;
            }

            selected = [...new Set(parts.map(Number))]
                .map(n => enabledProjects[n - 1]);
        }

        rl.close();
        console.log("\\nSelected:");
        selected.forEach(p => console.log(`- ${p.name}`));
        startNext();
    });
}

function startNext() {
    if (stopping) return;

    if (index >= selected.length) {
        console.log("\\nAll selected projects have been launched.");
        console.log("They remain running. Press Ctrl+C to stop the launcher.");
        return;
    }

    const project = selected[index];
    const projectPath = path.resolve(project.path);

    console.log("\\n========================================");
    console.log(`Starting : ${project.name}`);
    console.log(`Folder   : ${projectPath}`);
    console.log(`Command  : ${project.command}`);
    console.log("========================================\\n");

    if (!fs.existsSync(projectPath) || !fs.statSync(projectPath).isDirectory()) {
        console.error(`Folder not found: ${projectPath}`);
        next();
        return;
    }

    const child = spawn(project.command, {
        cwd: projectPath,
        shell: true,
        stdio: "inherit"
    });

    running.push({ name: project.name, child });

    child.on("error", err => {
        console.error(`Could not launch ${project.name}: ${err.message}`);
    });

    child.on("exit", (code, signal) => {
        if (!stopping) {
            console.log(`\\n${project.name} exited (code: ${code}, signal: ${signal || "none"}).`);
        }
    });

    next();
}

function next() {
    index++;
    if (index < selected.length) {
        timer = setTimeout(startNext, START_DELAY_MS);
    } else {
        console.log("\\nAll selected projects have been launched.");
        console.log("Press Ctrl+C to stop the launcher.");
    }
}

function stopAll() {
    if (stopping) return;
    stopping = true;
    if (timer) clearTimeout(timer);

    console.log("\\nStopping launched commands...");
    for (const { name, child } of running) {
        if (child.exitCode === null && !child.killed) {
            console.log(`Stopping ${name}...`);
            child.kill("SIGTERM");
        }
    }
    setTimeout(() => process.exit(0), 1500);
}

process.on("SIGINT", stopAll);
process.on("SIGTERM", stopAll);

showMenu();
