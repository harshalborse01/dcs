ANGULAR CONFIGURABLE PROJECT LAUNCHER
======================================

1. Extract this ZIP.
2. Open run-all.js and edit the projects array at the top.
3. For each project, set:
   - name: a display name
   - path: absolute project folder path
   - command: exact command to run in that folder
   - enabled: true or false
4. Run from a terminal:

   node run-all.js

5. Select project numbers (example: 1,3), enter ALL, or enter 0 to exit.

EXAMPLE ENTRY
-------------
{
    name: "DigitalChequeService",
    path: "D:/Projects/ui/DigitalChequeService",
    command: "npm start",
    enabled: true
}

COMMAND EXAMPLES
----------------
"npm start"
"npm run dev"
"ng serve --port 4500"
"npm run start:uat"

Projects may be in completely different locations. Each command runs with
its working directory set to that project's configured folder.

The launcher starts selected projects five seconds apart. Previously launched
projects keep running while later ones start.

NOTES
-----
- Use absolute paths. Forward slashes are recommended for Windows paths.
- Set enabled: false to temporarily hide/skip a project.
- Ensure each project uses a distinct port if they run simultaneously.
- Install project dependencies before launching.
- Node.js must be installed. npm must be available for npm commands.
- The five-second interval is a launch delay, not a readiness check.
- Ctrl+C asks launched commands to stop. Some shell-launched child processes
  may require separate termination depending on the command and OS.
