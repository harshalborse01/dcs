import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MockDataService, PaidSearchRecord } from '../../core/services/mock-data.service';
import { TranslationService } from '../../core/services/translation.service';

type SearchPage = 'paid' | 'issued' | 'issuedFiles';

@Component({
  selector: 'app-search-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './search-page.component.html',
  styleUrls: ['./search-page.component.scss']
})
export class SearchPageComponent implements OnInit {
  private readonly pageContent: Record<SearchPage, { translationKey: string; fallback: string }> = {
    paid: { translationKey: 'nav.search.paid', fallback: 'Paid Search' },
    issued: { translationKey: 'nav.search.issued', fallback: 'Issued Search' },
    issuedFiles: { translationKey: 'nav.search.issuedFiles', fallback: 'Issued Files Search' }
  };

  private readonly currentPage: SearchPage;
  protected readonly isAccountMenuOpen = signal(false);
  protected readonly isStatusMenuOpen = signal(false);
  protected readonly isReturnCodeMenuOpen = signal(false);
  protected readonly isExceptionTypeMenuOpen = signal(false);
  protected readonly selectedAccounts = signal<string[]>([]);
  protected readonly selectedStatuses = signal<string[]>([]);
  protected readonly selectedReturnCodes = signal<string[]>([]);
  protected readonly selectedExceptionTypes = signal<string[]>([]);
  protected readonly paidSearchRecords = signal<PaidSearchRecord[]>([]);
  protected readonly filteredSearchRecords = signal<PaidSearchRecord[]>([]);
  protected readonly searchDataError = signal('');
  protected readonly selectedRecord = signal<PaidSearchRecord | null>(null);
  protected readonly statusOptions = [
    { value: 'paid', translationKey: 'search.status.paid', fallback: 'Paid' },
    { value: 'pending', translationKey: 'search.status.pending', fallback: 'Pending' },
    { value: 'return', translationKey: 'search.status.return', fallback: 'Return' },
    { value: 'return-pending', translationKey: 'search.status.returnPending', fallback: 'Return Pending' }
  ];
  protected readonly resultPage = signal(1);
  protected readonly resultPageSize = 10;
  protected readonly returnCodeOptions = [
    { value: 'account-closed', translationKey: 'search.returnCode.accountClosed', fallback: 'Account Closed' },
    { value: 'account-transferred', translationKey: 'search.returnCode.accountTransferred', fallback: 'Account Transferred to You' },
    { value: 'cannot-trace', translationKey: 'search.returnCode.cannotTrace', fallback: 'Cannot Trace' },
    { value: 'counterfeit-item', translationKey: 'exceptions.returnCodes.counterfeitItem', fallback: 'Counterfeit Item' },
    { value: 'drawer-deceased', translationKey: 'search.returnCode.drawerDeceased', fallback: 'Drawer Deceased' },
    { value: 'duplicate-payment', translationKey: 'exceptions.returnCodes.duplicatePayment', fallback: 'Duplicate Payment' },
    { value: 'forged-endorsement', translationKey: 'exceptions.returnCodes.forgedEndorsement', fallback: 'Forged Endorsement' },
    { value: 'forged-counterfeit-signature', translationKey: 'search.returnCode.forgedCounterfeitSignature', fallback: 'Forged/Counterfeit Signature' },
    { value: 'funds-frozen', translationKey: 'search.returnCode.fundsFrozen', fallback: 'Funds Frozen/Not Cleared' },
    { value: 'legal-process', translationKey: 'search.returnCode.legalProcess', fallback: 'Legal Process' },
    { value: 'insufficient-funds', translationKey: 'search.returnCode.insufficientFunds', fallback: 'Insufficient Funds' },
    { value: 'intended-payee-not-paid', translationKey: 'exceptions.returnCodes.intendedPayeeNotPaid', fallback: 'Intended Payee Not Paid' },
    { value: 'lost-or-stolen', translationKey: 'search.returnCode.lostOrStolen', fallback: 'Lost or Stolen Prior to Issue' },
    { value: 'micr-mismatch', translationKey: 'search.returnCode.micrMismatch', fallback: 'MICR Mismatch' },
    { value: 'material-alteration', translationKey: 'exceptions.returnCodes.materialAlteration', fallback: 'Material Alteration' },
    { value: 'missing-image', translationKey: 'search.returnCode.missingImage', fallback: 'Missing Image/Image Not Usable' },
    { value: 'no-cheque-privilege', translationKey: 'search.returnCode.noChequePrivilege', fallback: 'No Cheque Privilege' },
    { value: 'non-conforming-signature', translationKey: 'search.returnCode.nonConformingSignature', fallback: 'Non-conforming Signature' },
    { value: 'negotiation-clearing-error', translationKey: 'search.returnCode.negotiationClearingError', fallback: 'Negotiation/Clearing Error' },
    { value: 'not-in-us', translationKey: 'search.returnCode.notInUs', fallback: 'Not in US' },
    { value: 'payment-stopped', translationKey: 'exceptions.returnCodes.paymentStopped', fallback: 'Payment Stopped' },
    { value: 'post-dated', translationKey: 'search.returnCode.postDated', fallback: 'Post-Dated' },
    { value: 'refer-to-maker', translationKey: 'search.returnCode.referToMaker', fallback: 'Refer to Maker' },
    { value: 'returned-payment', translationKey: 'search.returnCode.returnedPayment', fallback: 'Returned Payment' },
    { value: 'stale-dated', translationKey: 'exceptions.returnCodes.staleDated', fallback: 'Stale Dated' },
    { value: 'unauthorized-payee', translationKey: 'search.returnCode.unauthorizedPayee', fallback: 'Unauthorized Payee' },
    { value: 'wrong-amount-currency', translationKey: 'exceptions.returnCodes.wrongAmountCurrency', fallback: 'Wrong Amount/Wrong Currency' },
    { value: 'wrong-account-number', translationKey: 'search.returnCode.wrongAccountNumber', fallback: 'Wrong Account Number' }
  ];
  protected readonly exceptionTypeOptions = [
    { value: 'amount-mismatch', translationKey: 'search.exceptionType.amountMismatch', fallback: 'Amount Mismatch' },
    { value: 'duplicate-item', translationKey: 'search.exceptionType.duplicateItem', fallback: 'Duplicate Item' },
    { value: 'no-image', translationKey: 'exceptions.noImage', fallback: 'No Image/Poor Quality Image' },
    { value: 'paid-not-issued', translationKey: 'exceptions.paidNotIssued', fallback: 'Paid/Not Issued' },
    { value: 'payee-mismatch', translationKey: 'search.exceptionType.payeeMismatch', fallback: 'Payee Mismatch' },
    { value: 'post-dated', translationKey: 'search.exceptionType.postDated', fallback: 'Post-Dated' },
    { value: 'stale-dated', translationKey: 'search.exceptionType.staleDated', fallback: 'Stale-Dated' },
    { value: 'void-exception', translationKey: 'search.exceptionType.voidException', fallback: 'Void Exception' }
  ];
  protected readonly accountOptions = [
    { name: 'DCS TEST2', transit: '01241 1716238', value: 'DCS TEST2 - 01241 1716238' },
    { name: 'DCS123', transit: '01241 1716299', value: 'DCS123 - 01241 1716299' }
  ];
  protected readonly searchSubmitted = signal(false);

  constructor(
    private readonly route: ActivatedRoute,
    private readonly mockDataService: MockDataService,
    private readonly translationService: TranslationService
  ) {
    const page = this.route.snapshot.data['searchPage'];
    this.currentPage = page === 'issued' || page === 'issuedFiles' ? page : 'paid';
  }

  ngOnInit(): void {
    this.mockDataService.getPaidSearchRecords().subscribe({
      next: (records) => this.paidSearchRecords.set(records),
      error: () => this.searchDataError.set(this.t('search.dataLoadError', 'Unable to load search records. Please try again later.'))
    });
  }

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  protected getPageTitle(): string {
    const content = this.pageContent[this.currentPage];
    return this.t(content.translationKey, content.fallback);
  }

  protected isPaidSearch(): boolean {
    return this.currentPage === 'paid';
  }

  protected toggleAccountMenu(): void {
    this.isAccountMenuOpen.update((isOpen) => !isOpen);
  }

  protected toggleStatusMenu(): void {
    this.isStatusMenuOpen.update((isOpen) => !isOpen);
  }

  protected toggleReturnCodeMenu(): void {
    this.isReturnCodeMenuOpen.update((isOpen) => !isOpen);
  }

  protected toggleExceptionTypeMenu(): void {
    this.isExceptionTypeMenuOpen.update((isOpen) => !isOpen);
  }

  protected isStatusSelected(statusValue: string): boolean {
    return this.selectedStatuses().includes(statusValue);
  }

  protected isAllStatusesSelected(): boolean {
    return this.selectedStatuses().length === this.statusOptions.length;
  }

  protected isReturnCodeFilterVisible(): boolean {
    return this.selectedStatuses().includes('return') || this.selectedStatuses().includes('return-pending');
  }

  protected getStatusSelectionLabel(): string {
    const count = this.selectedStatuses().length;
    if (!count) {
      return this.t('search.selectStatus', 'Select Status');
    }

    const key = count === 1 ? 'search.statusSelected' : 'search.statusesSelected';
    const fallback = count === 1 ? '{count} status selected' : '{count} statuses selected';
    return this.t(key, fallback).replace('{count}', String(count));
  }

  protected getSelectedStatusOptions(): typeof this.statusOptions {
    return this.statusOptions.filter((status) => this.selectedStatuses().includes(status.value));
  }

  protected removeStatus(statusValue: string): void {
    this.selectedStatuses.update((selected) => selected.filter((value) => value !== statusValue));
  }

  protected toggleStatus(statusValue: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedStatuses.update((selected) =>
      checked
        ? [...selected, statusValue]
        : selected.filter((value) => value !== statusValue)
    );
    this.resetReturnCodesIfFilterHidden();
  }

  protected toggleAllStatuses(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedStatuses.set(checked ? this.statusOptions.map((status) => status.value) : []);
    this.resetReturnCodesIfFilterHidden();
  }

  private resetReturnCodesIfFilterHidden(): void {
    if (!this.isReturnCodeFilterVisible()) {
      this.selectedReturnCodes.set([]);
      this.isReturnCodeMenuOpen.set(false);
    }
  }

  protected isReturnCodeSelected(returnCodeValue: string): boolean {
    return this.selectedReturnCodes().includes(returnCodeValue);
  }

  protected isAllReturnCodesSelected(): boolean {
    return this.selectedReturnCodes().length === this.returnCodeOptions.length;
  }

  protected getReturnCodeSelectionLabel(): string {
    const count = this.selectedReturnCodes().length;
    if (!count) {
      return this.t('search.selectReturnCodes', 'Select Return Code(s)');
    }

    const key = count === 1 ? 'search.returnCodeSelected' : 'search.returnCodesSelected';
    const fallback = count === 1 ? '{count} return code selected' : '{count} return codes selected';
    return this.t(key, fallback).replace('{count}', String(count));
  }

  protected getSelectedReturnCodeOptions(): typeof this.returnCodeOptions {
    return this.returnCodeOptions.filter((returnCode) => this.selectedReturnCodes().includes(returnCode.value));
  }

  protected removeReturnCode(returnCodeValue: string): void {
    this.selectedReturnCodes.update((selected) => selected.filter((value) => value !== returnCodeValue));
  }

  protected toggleReturnCode(returnCodeValue: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedReturnCodes.update((selected) =>
      checked
        ? [...selected, returnCodeValue]
        : selected.filter((value) => value !== returnCodeValue)
    );
  }

  protected toggleAllReturnCodes(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedReturnCodes.set(checked ? this.returnCodeOptions.map((returnCode) => returnCode.value) : []);
  }

  protected isExceptionTypeSelected(typeValue: string): boolean {
    return this.selectedExceptionTypes().includes(typeValue);
  }

  protected isAllExceptionTypesSelected(): boolean {
    return this.selectedExceptionTypes().length === this.exceptionTypeOptions.length;
  }

  protected getExceptionTypeSelectionLabel(): string {
    const count = this.selectedExceptionTypes().length;
    if (!count) {
      return this.t('search.selectExceptionTypes', 'Select Exception Type(s)');
    }

    const key = count === 1 ? 'search.exceptionTypeSelected' : 'search.exceptionTypesSelected';
    const fallback = count === 1 ? '{count} exception type selected' : '{count} exception types selected';
    return this.t(key, fallback).replace('{count}', String(count));
  }

  protected getSelectedExceptionTypeOptions(): typeof this.exceptionTypeOptions {
    return this.exceptionTypeOptions.filter((type) => this.selectedExceptionTypes().includes(type.value));
  }

  protected removeExceptionType(typeValue: string): void {
    this.selectedExceptionTypes.update((selected) => selected.filter((value) => value !== typeValue));
  }

  protected toggleExceptionType(typeValue: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedExceptionTypes.update((selected) =>
      checked
        ? [...selected, typeValue]
        : selected.filter((value) => value !== typeValue)
    );
  }

  protected toggleAllExceptionTypes(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedExceptionTypes.set(checked ? this.exceptionTypeOptions.map((type) => type.value) : []);
  }

  protected isAccountSelected(accountValue: string): boolean {
    return this.selectedAccounts().includes(accountValue);
  }

  protected getSelectedAccountOptions(): typeof this.accountOptions {
    return this.accountOptions.filter((account) => this.selectedAccounts().includes(account.value));
  }

  protected removeAccount(accountValue: string): void {
    this.selectedAccounts.update((selected) => selected.filter((value) => value !== accountValue));
  }

  protected isSelectAllSelected(): boolean {
    return this.selectedAccounts().length === this.accountOptions.length;
  }

  protected toggleAccount(accountValue: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedAccounts.update((selected) =>
      checked
        ? [...selected, accountValue]
        : selected.filter((value) => value !== accountValue)
    );
  }

  protected toggleSelectAll(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedAccounts.set(checked ? this.accountOptions.map((account) => account.value) : []);
  }

  protected getVisibleSearchRecords(): PaidSearchRecord[] {
    const start = (this.resultPage() - 1) * this.resultPageSize;
    return this.filteredSearchRecords().slice(start, start + this.resultPageSize);
  }

  protected getResultPageCount(): number {
    return Math.max(1, Math.ceil(this.filteredSearchRecords().length / this.resultPageSize));
  }

  protected getResultSummary(): string {
    const total = this.filteredSearchRecords().length;
    if (!total) {
      return this.t('search.resultsSummaryEmpty', 'Total results found matching your search criteria: 0');
    }

    const first = (this.resultPage() - 1) * this.resultPageSize + 1;
    const last = Math.min(first + this.resultPageSize - 1, total);
    return this.t('search.resultsSummary', 'Total results found matching your search criteria: {first} - {last} of {total}')
      .replace('{first}', String(first))
      .replace('{last}', String(last))
      .replace('{total}', String(total));
  }

  protected previousResultPage(): void {
    this.resultPage.update((page) => Math.max(1, page - 1));
  }

  protected nextResultPage(): void {
    this.resultPage.update((page) => Math.min(this.getResultPageCount(), page + 1));
  }

  protected openRecordDetails(record: PaidSearchRecord): void {
    this.selectedRecord.set(record);
  }

  protected closeRecordDetails(): void {
    this.selectedRecord.set(null);
  }

  protected getStatusLabel(status: string): string {
    const option = this.statusOptions.find((item) => item.value === status);
    return option ? this.t(option.translationKey, option.fallback) : status.charAt(0).toUpperCase() + status.slice(1);
  }

  protected getReturnCodeLabel(returnCode: string | null): string {
    if (!returnCode) {
      return '–';
    }

    const option = this.returnCodeOptions.find((item) => item.value === returnCode);
    return option ? this.t(option.translationKey, option.fallback) : returnCode;
  }

  private toNumber(value: string): number | null {
    if (!value) {
      return null;
    }

    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }

  protected search(form: HTMLFormElement): void {
    const formData = new FormData(form);
    const value = (name: string): string => String(formData.get(name) ?? '').trim();
    const serialFrom = this.toNumber(value('serialFrom'));
    const serialTo = this.toNumber(value('serialTo'));
    const amountFrom = this.toNumber(value('amountFrom'));
    const amountTo = this.toNumber(value('amountTo'));
    const startDate = value('startDate');
    const endDate = value('endDate');

    const results = this.paidSearchRecords().filter((record) => {
      const serialNumber = Number(record.serialNumber);
      return record.searchType === value('searchType') &&
        record.customer === value('customer') &&
        (!this.selectedAccounts().length || this.selectedAccounts().includes(record.account)) &&
        (serialFrom === null || serialNumber >= serialFrom) &&
        (serialTo === null || serialNumber <= serialTo) &&
        (amountFrom === null || record.amount >= amountFrom) &&
        (amountTo === null || record.amount <= amountTo) &&
        (!startDate || record.clearingDate >= startDate) &&
        (!endDate || record.clearingDate <= endDate) &&
        (!this.selectedStatuses().length || this.selectedStatuses().includes(record.status)) &&
        (!this.selectedReturnCodes().length || (record.returnCode !== null && this.selectedReturnCodes().includes(record.returnCode))) &&
        (!this.selectedExceptionTypes().length || record.exceptionTypes.some((type) => this.selectedExceptionTypes().includes(type)));
    });

    this.filteredSearchRecords.set(results);
    this.resultPage.set(1);
    this.searchSubmitted.set(true);
  }

  protected clearSearch(form: HTMLFormElement): void {
    form.reset();
    this.selectedAccounts.set([]);
    this.selectedStatuses.set([]);
    this.selectedReturnCodes.set([]);
    this.selectedExceptionTypes.set([]);
    this.filteredSearchRecords.set([]);
    this.resultPage.set(1);
    this.searchSubmitted.set(false);
    this.isAccountMenuOpen.set(false);
    this.isStatusMenuOpen.set(false);
    this.isReturnCodeMenuOpen.set(false);
    this.isExceptionTypeMenuOpen.set(false);
  }
}
