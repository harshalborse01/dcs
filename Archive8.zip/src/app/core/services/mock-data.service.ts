import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

export interface HeaderSubmenuItem {
  label: string;
  route: string;
  href?: string;
}

export interface HeaderNavigationItem {
  label: string;
  route: string;
  hasDropdown?: boolean;
  submenu?: HeaderSubmenuItem[];
}

export interface HeaderData {
  brand: string;
  navigation: HeaderNavigationItem[];
  reportingPeriod: string;
  userId: string;
  reportingPeriodMenu?: HeaderSubmenuItem[];
  notificationCount: number;
}

export interface NavigationCardItem {
  label: string;
  route: string;
  icon: 'search' | 'file-text';
}

export interface NotificationMessage {
  id: string;
  message: string;
  type: 'info';
}

export interface NotificationNotice {
  id: string;
  message: string;
  linkText?: string;
}

export interface NotificationData {
  count: number;
  items: NotificationMessage[];
  notices: NotificationNotice[];
}

export interface SearchRecord {
  id: string;
  title: string;
  category: string;
  description: string;
}

export interface PaidSearchRecord {
  id: string;
  searchType: 'paid';
  customer: string;
  account: string;
  serialNumber: string;
  amount: number;
  clearingDate: string;
  status: string;
  returnCode: string | null;
  exceptionTypes: string[];
  difference: string;
  editable: boolean;
}

export interface ReportItem {
  id: string;
  title: string;
  period: string;
  status: string;
}

const HEADER_DATA: HeaderData = {
  brand: 'BMO',
  navigation: [
    { label: 'Home', route: '/home' },
    {
      label: 'Exceptions',
      route: '/exceptions'
    },
    {
      label: 'Search',
      route: '/search',
      hasDropdown: true,
      submenu: [
        { label: 'Paid Search', route: '/search/paid' },
        { label: 'Issued Search', route: '/search/issued' },
        { label: 'Issued Files Search', route: '/search/issued-files' }
      ]
    },
    {
      label: 'Reports',
      route: '/reports',
      hasDropdown: true,
      submenu: [
        { label: 'Customer Reports', route: '/reports' },
        { label: 'Report Retrieval', route: '/report-retrieval' }
      ]
    },
    {
      label: 'Uploads',
      route: '/uploads',
      hasDropdown: true,
      submenu: [
        { label: 'Add Issued Record', route: '/uploads' }
      ]
    }
  ],
  reportingPeriod: '20265454',
  userId: '20265454',
  reportingPeriodMenu: [
    { label: 'Help', route: '/home' },
    { label: 'Contact Us', route: '/contact-us' },
    { label: 'CPA Information', route: '/home', href: '/assets/documents/cpa-information.pdf' },
    { label: 'Printer Friendly Format', route: '/home' }
  ],
  notificationCount: 3
};

const NAVIGATION_CARDS: NavigationCardItem[] = [
  { label: 'Exception', route: '/exceptions', icon: 'file-text' },
  { label: 'Search', route: '/search', icon: 'search' },
  { label: 'Reports', route: '/reports', icon: 'file-text' },
  { label: 'Uploads', route: '/uploads', icon: 'file-text' }
];

const NOTIFICATION_DATA: NotificationData = {
  count: 3,
  items: [
    {
      id: 'notification-1',
      message: 'One or more transit/account(s) is inaccessible: 012411716119:, please contact your Administrator.',
      type: 'info'
    }
  ],
  notices: [
    {
      id: 'notice-1',
      message: 'test - English Test 1 August 14, 2023 October 25, 2024 March 20, 2025 September 29, 2026 ',
      linkText: 'TONCAT - May 2025'
    },
    {
      id: 'notice-2',
      message: 'Feb. 2025 - ENG March 20, 2025 ',
      linkText: 'Struts 2025 - Eng'
    },
    {
      id: 'notice-3',
      message: 'August 14, 2023'
    }
  ]
};

const SEARCH_RESULTS: SearchRecord[] = [
  {
    id: 'sr1',
    title: 'Paid Search',
    category: 'Search',
    description: 'Search results for postal and account transactions.'
  },
  {
    id: 'sr2',
    title: 'Customer Reports',
    category: 'Reports',
    description: 'Customer data retrieval and report summary list.'
  },
  {
    id: 'sr3',
    title: 'Report Retrieval',
    category: 'Operations',
    description: 'Retrieves generated statements and archived reports.'
  }
];

const REPORTS: ReportItem[] = [
  { id: 'r1', title: 'Customer Reports', period: 'Q1 2026', status: 'Ready' },
  { id: 'r2', title: 'Report Retrieval', period: 'Q2 2026', status: 'Pending' },
  { id: 'r3', title: 'Paid Search', period: 'Annual 2026', status: 'Ready' }
];

@Injectable({ providedIn: 'root' })
export class MockDataService {
  constructor(private readonly http: HttpClient) {}

  getHeaderData(): Observable<HeaderData> {
    return of(HEADER_DATA);
  }

  getNavigationCards(): Observable<NavigationCardItem[]> {
    return of(NAVIGATION_CARDS);
  }

  getNotifications(): Observable<NotificationData> {
    return of(NOTIFICATION_DATA);
  }

  getSearchResults(): Observable<SearchRecord[]> {
    return of(SEARCH_RESULTS);
  }

  getPaidSearchRecords(): Observable<PaidSearchRecord[]> {
    return this.http.get<PaidSearchRecord[]>('/assets/mock-data/paid-search-records.json');
  }

  getReports(): Observable<ReportItem[]> {
    return of(REPORTS);
  }

  getStaticSiteMap(): Observable<string[]> {
    return of(['/home', '/search', '/reports', '/sitemap']);
  }
}
