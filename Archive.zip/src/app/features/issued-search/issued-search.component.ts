import { CommonModule } from '@angular/common';
import { Component, OnInit, computed, signal } from '@angular/core';
import { Router } from '@angular/router';
import { IssuedSearchRecord, MockDataService } from '../../core/services/mock-data.service';
import { TranslationService } from '../../core/services/translation.service';

type IssuedSearchCriteria = {
  customer: string;
  serialFrom: number | null;
  serialTo: number | null;
  payeeName: string;
  amountFrom: number | null;
  amountTo: number | null;
  startDate: string;
  endDate: string;
  accounts: string[];
  statuses: string[];
  returnCodes: string[];
};

@Component({
  selector: 'app-issued-search',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './issued-search.component.html',
  styleUrl: './issued-search.component.scss'
})
export class IssuedSearchComponent implements OnInit {
  private readonly defaultDate = '2026-10-26';
  protected readonly records = signal<IssuedSearchRecord[]>([]);
  protected readonly results = signal<IssuedSearchRecord[]>([]);
  protected readonly submitted = signal(false);
  protected readonly dataError = signal('');
  protected readonly page = signal(1);
  protected readonly pageSize = 10;
  protected readonly accountMenuOpen = signal(false);
  protected readonly statusMenuOpen = signal(false);
  protected readonly returnCodeMenuOpen = signal(false);
  protected readonly dateEntryType = signal<'dropdown' | 'freeForm'>('dropdown');
  protected readonly startDate = signal(this.defaultDate);
  protected readonly endDate = signal(this.defaultDate);
  protected readonly startDateFreeForm = signal('10/26/2026');
  protected readonly endDateFreeForm = signal('10/26/2026');
  protected readonly dateEntryError = signal('');
  protected readonly rowActions = signal<Record<string, string>>({});
  protected readonly changeAllAction = signal('');
  protected readonly selectedActionRecords = computed(() =>
    this.results().filter((record) => Boolean(this.rowActions()[record.id]))
  );
  protected readonly reviewMode = signal(false);
  protected readonly reviewConfirmed = signal(false);
  protected readonly reviewProcessedAt = signal('');
  protected readonly reviewNoticeVisible = signal(true);
  protected readonly selectedHistoryRecord = signal<IssuedSearchRecord | null>(null);
  protected readonly memoInput = signal('');
  protected readonly memoEntries = signal<Array<{ date: string; comment: string; user: string }>>([]);
  protected readonly processingHistoryRows = [
    { date: '01:51 PM EDT\n10/14/2026', description: 'Loaded', oldData: '', newData: '', user: 'System' },
    { date: '01:51 PM EDT\n10/14/2026', description: 'QA Exception Flag', oldData: '', newData: '', user: 'System' },
    { date: '01:41 PM EDT\n10/14/2026', description: 'Exception paid not issued', oldData: '', newData: '', user: 'System' },
    { date: '01:41 PM EDT\n10/14/2026', description: 'Exception no image/poor quality image', oldData: '', newData: '', user: 'System' },
    { date: '00:53 AM EDT\n10/20/2026', description: 'Paid Online', oldData: '', newData: '', user: '30358118_PCA14' }
  ];

  protected readonly accountOptions = [
    { name: 'PP PIF Custom', transit: '80002 1313155', value: 'PP PIF Custom - 80002 1313155' },
    { name: 'LargeAmount', transit: '80002 1910070', value: 'LargeAmount - 80002 1910070' }
  ];

  protected readonly statusOptions = [
    { value: 'paid', label: 'Paid', translationKey: 'search.status.paid' },
    { value: 'pending', label: 'Pending', translationKey: 'search.status.pending' },
    { value: 'return', label: 'Return', translationKey: 'search.status.return' },
    { value: 'return-pending', label: 'Return Pending', translationKey: 'search.status.returnPending' },
    { value: 'void', label: 'Void', translationKey: 'search.status.void' }
  ];
  protected readonly actionOptions = [
    { value: 'void', label: 'Void' },
    { value: 'deleted', label: 'Deleted' }
  ];
  protected readonly selectedActionGroups = computed(() =>
    this.actionOptions
      .map((action) => ({
        ...action,
        records: this.selectedActionRecords().filter((record) => this.rowActions()[record.id] === action.value)
      }))
      .filter((action) => action.records.length > 0)
  );

  protected readonly selectedAccounts = signal<string[]>([]);
  protected readonly selectedStatuses = signal<string[]>([]);
  protected readonly selectedReturnCodes = signal<string[]>([]);
  protected readonly returnCodeOptions = [
    { value: 'account-closed', translationKey: 'search.returnCode.accountClosed', fallback: 'Account Closed' },
    { value: 'account-transferred', translationKey: 'search.returnCode.accountTransferred', fallback: 'Account Transferred to You' },
    { value: 'cannot-trace', translationKey: 'search.returnCode.cannotTrace', fallback: 'Cannot Trace' },
    { value: 'counterfeit-item', translationKey: 'exceptions.returnCodes.counterfeitItem', fallback: 'Counterfeit Item' },
    { value: 'drawer-deceased', translationKey: 'search.returnCode.drawerDeceased', fallback: 'Drawer Deceased' },
    { value: 'duplicate-payment', translationKey: 'exceptions.returnCodes.duplicatePayment', fallback: 'Duplicate Payment' },
    { value: 'forged-endorsement', translationKey: 'exceptions.returnCodes.forgedEndorsement', fallback: 'Forged Endorsement' },
    { value: 'forged-counterfeit-signature', translationKey: 'search.returnCode.forgedCounterfeitSignature', fallback: 'Forged/Counterfeit Signature' },
    { value: 'funds-frozen', translationKey: 'search.returnCode.fundsFrozen', fallback: 'Funds Frozen/Not Cleared' },
    { value: 'legal-process', translationKey: 'search.returnCode.legalProcess', fallback: 'Legal Process' },
    { value: 'insufficient-funds', translationKey: 'search.returnCode.insufficientFunds', fallback: 'Insufficient Funds' },
    { value: 'intended-payee-not-paid', translationKey: 'exceptions.returnCodes.intendedPayeeNotPaid', fallback: 'Intended Payee Not Paid' },
    { value: 'lost-or-stolen', translationKey: 'search.returnCode.lostOrStolen', fallback: 'Lost or Stolen Prior to Issue' },
    { value: 'micr-mismatch', translationKey: 'search.returnCode.micrMismatch', fallback: 'MICR Mismatch' },
    { value: 'material-alteration', translationKey: 'exceptions.returnCodes.materialAlteration', fallback: 'Material Alteration' },
    { value: 'missing-image', translationKey: 'search.returnCode.missingImage', fallback: 'Missing Image/Image Not Usable' },
    { value: 'no-cheque-privilege', translationKey: 'search.returnCode.noChequePrivilege', fallback: 'No Cheque Privilege' },
    { value: 'non-conforming-signature', translationKey: 'search.returnCode.nonConformingSignature', fallback: 'Non-conforming Signature' },
    { value: 'negotiation-clearing-error', translationKey: 'search.returnCode.negotiationClearingError', fallback: 'Negotiation/Clearing Error' },
    { value: 'not-in-us', translationKey: 'search.returnCode.notInUs', fallback: 'Not in US' },
    { value: 'payment-stopped', translationKey: 'exceptions.returnCodes.paymentStopped', fallback: 'Payment Stopped' },
    { value: 'post-dated', translationKey: 'search.returnCode.postDated', fallback: 'Post-Dated' },
    { value: 'refer-to-maker', translationKey: 'search.returnCode.referToMaker', fallback: 'Refer to Maker' },
    { value: 'returned-payment', translationKey: 'search.returnCode.returnedPayment', fallback: 'Returned Payment' },
    { value: 'stale-dated', translationKey: 'exceptions.returnCodes.staleDated', fallback: 'Stale Dated' },
    { value: 'unauthorized-payee', translationKey: 'search.returnCode.unauthorizedPayee', fallback: 'Unauthorized Payee' },
    { value: 'wrong-amount-currency', translationKey: 'exceptions.returnCodes.wrongAmountCurrency', fallback: 'Wrong Amount/Wrong Currency' },
    { value: 'wrong-account-number', translationKey: 'search.returnCode.wrongAccountNumber', fallback: 'Wrong Account Number' }
  ];
  constructor(
    private readonly router: Router,
    private readonly mockDataService: MockDataService,
    private readonly translationService: TranslationService
  ) {}

  ngOnInit(): void {
    this.mockDataService.getIssuedSearchRecords().subscribe({
      next: (records) => this.records.set(records),
      error: () => this.dataError.set(this.t('search.dataLoadError', 'Unable to load search records. Please try again later.'))
    });
  }

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  protected changeSearchType(event: Event): void {
    const searchType = (event.target as HTMLSelectElement).value;
    const routeBySearchType: Record<string, string> = {
      paid: '/search/paid',
      issued: '/search/issued',
      issuedFiles: '/search/issued-files'
    };
    const route = routeBySearchType[searchType];

    if (route) {
      void this.router.navigateByUrl(route);
    }
  }

  protected search(form: HTMLFormElement): void {
    this.reviewMode.set(false);
    this.reviewConfirmed.set(false);
    this.rowActions.set({});
    this.changeAllAction.set('');
    const formData = new FormData(form);
    const value = (name: string): string => String(formData.get(name) ?? '').trim();
    const numberValue = (name: string): number | null => {
      const rawValue = value(name);
      if (!rawValue) {
        return null;
      }

      const parsed = Number(rawValue);
      return Number.isFinite(parsed) ? parsed : null;
    };
    const startDate = this.getSearchDate('start');
    const endDate = this.getSearchDate('end');
    if (startDate === null || endDate === null) {
      this.dateEntryError.set(this.t('search.invalidDateFormat', 'Enter a valid date in MM/DD/YYYY format.'));
      return;
    }

    this.dateEntryError.set('');
    const criteria: IssuedSearchCriteria = {
      customer: value('customer'),
      serialFrom: numberValue('serialFrom'),
      serialTo: numberValue('serialTo'),
      payeeName: value('payeeName').toLocaleLowerCase(),
      amountFrom: numberValue('amountFrom'),
      amountTo: numberValue('amountTo'),
      startDate,
      endDate,
      accounts: [...this.selectedAccounts()],
      statuses: [...this.selectedStatuses()],
      returnCodes: [...this.selectedReturnCodes()]
    };

    this.results.set(this.records().filter((record) => {
      const serialNumber = Number(record.serialNumber);
      return record.customer === criteria.customer &&
        (!criteria.accounts.length || criteria.accounts.includes(record.account)) &&
        (criteria.serialFrom === null || serialNumber >= criteria.serialFrom) &&
        (criteria.serialTo === null || serialNumber <= criteria.serialTo) &&
        (!criteria.payeeName || (record.payeeName ?? '').toLocaleLowerCase().includes(criteria.payeeName)) &&
        (criteria.amountFrom === null || record.amount >= criteria.amountFrom) &&
        (criteria.amountTo === null || record.amount <= criteria.amountTo) &&
        (!criteria.startDate || record.issuedDate >= criteria.startDate) &&
        (!criteria.endDate || record.issuedDate <= criteria.endDate) &&
        (!criteria.statuses.length || criteria.statuses.includes(record.status)) &&
        (!criteria.returnCodes.length || (record.returnCode !== null && criteria.returnCodes.includes(record.returnCode)));
    }));
    this.page.set(1);
    this.submitted.set(true);
  }

  protected clear(form: HTMLFormElement): void {
    form.reset();
    this.reviewMode.set(false);
    this.reviewConfirmed.set(false);
    this.reviewProcessedAt.set('');
    this.reviewNoticeVisible.set(true);
    this.dateEntryType.set('dropdown');
    this.startDate.set(this.defaultDate);
    this.endDate.set(this.defaultDate);
    this.startDateFreeForm.set('10/26/2026');
    this.endDateFreeForm.set('10/26/2026');
    this.dateEntryError.set('');
    this.rowActions.set({});
    this.changeAllAction.set('');
    this.selectedAccounts.set([]);
    this.selectedStatuses.set([]);
    this.selectedReturnCodes.set([]);
    this.accountMenuOpen.set(false);
    this.statusMenuOpen.set(false);
    this.returnCodeMenuOpen.set(false);
    this.results.set([]);
    this.page.set(1);
    this.submitted.set(false);
  }

  protected getVisibleResults(): IssuedSearchRecord[] {
    const start = (this.page() - 1) * this.pageSize;
    return this.results().slice(start, start + this.pageSize);
  }

  protected getVisibleAccountGroups(): Array<{ account: string; customer: string; records: IssuedSearchRecord[] }> {
    const groups = new Map<string, { account: string; customer: string; records: IssuedSearchRecord[] }>();
    for (const record of this.getVisibleResults()) {
      let group = groups.get(record.account);
      if (!group) {
        group = { account: record.account, customer: record.customer, records: [] };
        groups.set(record.account, group);
      }
      group.records.push(record);
    }

    return [...groups.values()];
  }

  protected getRowAction(recordId: string): string {
    return this.rowActions()[recordId] ?? '';
  }

  protected setRowAction(recordId: string, event: Event): void {
    const action = (event.target as HTMLSelectElement).value;
    this.rowActions.update((actions) => ({ ...actions, [recordId]: action }));
  }

  protected openProcessingHistory(record: IssuedSearchRecord): void {
    this.selectedHistoryRecord.set(record);
  }

  protected closeProcessingHistory(): void {
    this.selectedHistoryRecord.set(null);
    this.memoInput.set('');
  }

  protected addMemo(): void {
    const value = this.memoInput().trim();
    if (!value) {
      return;
    }

    const now = new Date();
    const time = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/Toronto',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
      timeZoneName: 'short'
    }).format(now).replace(/^12(?=:.*\bAM\b)/, '00');
    const date = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/Toronto',
      month: '2-digit',
      day: '2-digit',
      year: 'numeric'
    }).format(now);

    this.memoEntries.update((entries) => [
      ...entries,
      { date: `${time}\n${date}`, comment: value, user: 'Current User' }
    ]);
    this.memoInput.set('');
  }

  protected setChangeAllAction(event: Event): void {
    const action = (event.target as HTMLSelectElement).value;
    this.changeAllAction.set(action);
    const resultRecordIds = new Set(this.results().map((record) => record.id));
    this.rowActions.update((actions) => {
      const updatedActions = { ...actions };
      for (const recordId of resultRecordIds) {
        if (action) {
          updatedActions[recordId] = action;
        } else {
          delete updatedActions[recordId];
        }
      }
      return updatedActions;
    });
  }

  protected openReview(): void {
    if (!this.selectedActionRecords().length) {
      return;
    }

    this.reviewConfirmed.set(false);
    this.reviewProcessedAt.set('');
    this.reviewNoticeVisible.set(true);
    this.reviewMode.set(true);
  }

  protected submitReview(): void {
    if (!this.selectedActionRecords().length) {
      return;
    }

    const now = new Date();
    const time = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/Toronto',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
      timeZoneName: 'short'
    }).format(now);
    const date = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/Toronto',
      month: '2-digit',
      day: '2-digit',
      year: 'numeric'
    }).format(now);

    this.reviewProcessedAt.set(`${time}, ${date}`);
    this.reviewConfirmed.set(true);
    this.reviewNoticeVisible.set(true);
  }

  protected backFromReview(): void {
    if (this.reviewConfirmed()) {
      this.reviewConfirmed.set(false);
      this.reviewProcessedAt.set('');
      this.reviewNoticeVisible.set(true);
      return;
    }

    this.reviewMode.set(false);
    this.rowActions.set({});
    this.changeAllAction.set('');
  }

  protected dismissReviewNotice(): void {
    this.reviewNoticeVisible.set(false);
  }

  protected getPageCount(): number {
    return Math.max(1, Math.ceil(this.results().length / this.pageSize));
  }

  protected getResultSummary(): string {
    const total = this.results().length;
    if (!total) {
      return this.t('search.resultsSummaryEmpty', 'Total results found matching your search criteria: 0');
    }

    const first = (this.page() - 1) * this.pageSize + 1;
    const last = Math.min(first + this.pageSize - 1, total);
    return this.t('search.resultsSummary', 'Total results found matching your search criteria: {first} - {last} of {total}')
      .replace('{first}', String(first))
      .replace('{last}', String(last))
      .replace('{total}', String(total));
  }

  protected previousPage(): void {
    this.page.update((page) => Math.max(1, page - 1));
  }

  protected nextPage(): void {
    this.page.update((page) => Math.min(this.getPageCount(), page + 1));
  }

  protected getStatusLabel(status: string): string {
    const option = this.statusOptions.find((item) => item.value === status);
    return option ? this.t(option.translationKey, option.label) : status;
  }

  protected setDateEntryType(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    if (value === 'dropdown' || value === 'freeForm') {
      this.dateEntryType.set(value);
      this.dateEntryError.set('');
    }
  }

  protected updateDate(which: 'start' | 'end', event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    const isoDate = which === 'start' ? this.startDate : this.endDate;
    const freeFormDate = which === 'start' ? this.startDateFreeForm : this.endDateFreeForm;
    isoDate.set(value);
    freeFormDate.set(value ? this.formatDateAsText(value) : '');
    this.dateEntryError.set('');
  }

  protected updateFreeFormDate(which: 'start' | 'end', event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    const freeFormDate = which === 'start' ? this.startDateFreeForm : this.endDateFreeForm;
    const isoDate = which === 'start' ? this.startDate : this.endDate;
    freeFormDate.set(value);
    const parsedDate = this.parseFreeFormDate(value);
    if (parsedDate) {
      isoDate.set(parsedDate);
      this.dateEntryError.set('');
    }
  }

  private getSearchDate(which: 'start' | 'end'): string | null {
    if (this.dateEntryType() === 'dropdown') {
      return which === 'start' ? this.startDate() : this.endDate();
    }

    const text = which === 'start' ? this.startDateFreeForm() : this.endDateFreeForm();
    return text ? this.parseFreeFormDate(text) : '';
  }

  private parseFreeFormDate(value: string): string | null {
    const match = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value.trim());
    if (!match) {
      return null;
    }

    const [, month, day, year] = match;
    const date = new Date(Date.UTC(Number(year), Number(month) - 1, Number(day)));
    if (
      date.getUTCFullYear() !== Number(year) ||
      date.getUTCMonth() !== Number(month) - 1 ||
      date.getUTCDate() !== Number(day)
    ) {
      return null;
    }

    return `${year}-${month}-${day}`;
  }

  private formatDateAsText(value: string): string {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
    return match ? `${match[2]}/${match[3]}/${match[1]}` : '';
  }

  protected getReturnCodeLabel(returnCode: string | null): string {
    if (!returnCode) {
      return '–';
    }

    const option = this.returnCodeOptions.find((item) => item.value === returnCode);
    return option ? this.t(option.translationKey, option.fallback) : returnCode;
  }

  protected getExceptionTypeLabel(exceptionType: string): string {
    const labels: Record<string, { translationKey: string; fallback: string }> = {
      'amount-mismatch': { translationKey: 'search.exceptionType.amountMismatch', fallback: 'Amount Mismatch' },
      'duplicate-item': { translationKey: 'search.exceptionType.duplicateItem', fallback: 'Duplicate Item' },
      'no-image': { translationKey: 'exceptions.noImage', fallback: 'No Image/Poor Quality Image' },
      'paid-not-issued': { translationKey: 'exceptions.paidNotIssued', fallback: 'Paid/Not Issued' },
      'payee-mismatch': { translationKey: 'search.exceptionType.payeeMismatch', fallback: 'Payee Mismatch' },
      'post-dated': { translationKey: 'search.exceptionType.postDated', fallback: 'Post-Dated' },
      'stale-dated': { translationKey: 'search.exceptionType.staleDated', fallback: 'Stale-Dated' },
      'void-exception': { translationKey: 'search.exceptionType.voidException', fallback: 'Void Exception' }
    };
    const label = labels[exceptionType];
    return label ? this.t(label.translationKey, label.fallback) : exceptionType;
  }

  protected toggleAccountMenu(): void {
    this.accountMenuOpen.update((open) => !open);
  }

  protected toggleStatusMenu(): void {
    this.statusMenuOpen.update((open) => !open);
  }

  protected toggleAccount(account: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedAccounts.update((selected) => checked
      ? [...selected, account]
      : selected.filter((item) => item !== account));
  }

  protected toggleStatus(status: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedStatuses.update((selected) => checked
      ? [...selected, status]
      : selected.filter((item) => item !== status));
    this.resetReturnCodesIfFilterHidden();
  }

  protected isAccountSelected(account: string): boolean {
    return this.selectedAccounts().includes(account);
  }

  protected isAllAccountsSelected(): boolean {
    return this.selectedAccounts().length === this.accountOptions.length;
  }

  protected toggleSelectAllAccounts(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedAccounts.set(checked ? this.accountOptions.map((account) => account.value) : []);
  }

  protected isStatusSelected(status: string): boolean {
    return this.selectedStatuses().includes(status);
  }

  protected removeAccount(account: string): void {
    this.selectedAccounts.update((selected) => selected.filter((item) => item !== account));
  }

  protected removeStatus(status: string): void {
    this.selectedStatuses.update((selected) => selected.filter((item) => item !== status));
    this.resetReturnCodesIfFilterHidden();
  }

  protected getSelectedAccountOptions(): typeof this.accountOptions {
    return this.accountOptions.filter((account) => this.selectedAccounts().includes(account.value));
  }

  protected getSelectedStatusOptions(): typeof this.statusOptions {
    return this.statusOptions.filter((status) => this.selectedStatuses().includes(status.value));
  }

  protected isReturnCodeFilterVisible(): boolean {
    return this.selectedStatuses().includes('return') || this.selectedStatuses().includes('return-pending');
  }

  protected getStatusSelectionLabel(): string {
    const count = this.selectedStatuses().length;
    if (!count) {
      return this.t('search.selectStatus', 'Select Status');
    }

    const key = count === 1 ? 'search.statusSelected' : 'search.statusesSelected';
    const fallback = count === 1 ? '{count} status selected' : '{count} statuses selected';
    return this.t(key, fallback).replace('{count}', String(count));
  }

  protected isAllStatusesSelected(): boolean {
    return this.selectedStatuses().length === this.statusOptions.length;
  }

  protected toggleAllStatuses(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedStatuses.set(checked ? this.statusOptions.map((status) => status.value) : []);
    this.resetReturnCodesIfFilterHidden();
  }

  protected getReturnCodeSelectionLabel(): string {
    const count = this.selectedReturnCodes().length;
    if (!count) {
      return this.t('search.selectReturnCodes', 'Select Return Code(s)');
    }

    const key = count === 1 ? 'search.returnCodeSelected' : 'search.returnCodesSelected';
    const fallback = count === 1 ? '{count} return code selected' : '{count} return codes selected';
    return this.t(key, fallback).replace('{count}', String(count));
  }

  protected getSelectedReturnCodeOptions(): typeof this.returnCodeOptions {
    return this.returnCodeOptions.filter((option) => this.selectedReturnCodes().includes(option.value));
  }

  protected isReturnCodeSelected(value: string): boolean {
    return this.selectedReturnCodes().includes(value);
  }

  protected isAllReturnCodesSelected(): boolean {
    return this.selectedReturnCodes().length === this.returnCodeOptions.length;
  }

  protected toggleReturnCodeMenu(): void {
    this.returnCodeMenuOpen.update((open) => !open);
  }

  protected toggleReturnCode(value: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedReturnCodes.update((selected) => checked
      ? [...selected, value]
      : selected.filter((item) => item !== value));
  }

  protected toggleAllReturnCodes(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedReturnCodes.set(checked ? this.returnCodeOptions.map((option) => option.value) : []);
  }

  protected removeReturnCode(value: string): void {
    this.selectedReturnCodes.update((selected) => selected.filter((item) => item !== value));
  }

  private resetReturnCodesIfFilterHidden(): void {
    if (!this.isReturnCodeFilterVisible()) {
      this.selectedReturnCodes.set([]);
      this.returnCodeMenuOpen.set(false);
    }
  }
}
