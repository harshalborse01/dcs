import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { Router } from '@angular/router';
import { IssuedFilesSearchRecord, MockDataService } from '../../core/services/mock-data.service';
import { TranslationService } from '../../core/services/translation.service';

type IssuedFilesCriteria = {
  searchBy: 'fileDate' | 'reference';
  startDate: string;
  endDate: string;
  issuedFileNumber: string;
  accounts: string[];
};

type IssuedFilesStatusRow = {
  key: string;
  status: string;
  count: number;
  amount: number;
};

type IssuedFilesGroup = {
  key: string;
  customer: string;
  account: string;
  issuedDate: string;
  issuedFileNumber: string;
  statusRows: IssuedFilesStatusRow[];
};

@Component({
  selector: 'app-issued-files-search',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './issued-files-search.component.html',
  styleUrl: './issued-files-search.component.scss'
})
export class IssuedFilesSearchComponent implements OnInit {
  private readonly defaultDate = '2024-02-12';
  protected readonly records = signal<IssuedFilesSearchRecord[]>([]);
  protected readonly results = signal<IssuedFilesSearchRecord[]>([]);
  protected readonly dataError = signal('');
  protected readonly submitted = signal(false);
  protected readonly page = signal(1);
  protected readonly pageSize = 10;
  protected readonly accountMenuOpen = signal(false);
  protected readonly selectedAccounts = signal<string[]>([]);
  protected readonly searchBy = signal<'fileDate' | 'reference'>('fileDate');
  protected readonly startDate = signal(this.defaultDate);
  protected readonly endDate = signal(this.defaultDate);
  protected readonly deleteSelections = signal<Record<string, boolean>>({});

  protected readonly accountOptions = [
    { name: 'PP PIF Custom', transit: '80002 1313155', value: 'PP PIF Custom - 80002 1313155' },
    { name: 'LargeAmount', transit: '80002 1910070', value: 'LargeAmount - 80002 1910070' }
  ];
  protected readonly statusOptions = [
    { value: 'outstanding', label: 'Outstanding' },
    { value: 'stop', label: 'Stop' },
    { value: 'void', label: 'Void' },
    { value: 'paid', label: 'Paid' },
    { value: 'pending', label: 'Pending' },
    { value: 'rejected', label: 'Rejected' },
    { value: 'deleted', label: 'Deleted' }
  ];

  constructor(
    private readonly router: Router,
    private readonly mockDataService: MockDataService,
    private readonly translationService: TranslationService
  ) {}

  ngOnInit(): void {
    this.mockDataService.getIssuedFilesSearchRecords().subscribe({
      next: (records) => this.records.set(records),
      error: () => this.dataError.set(this.t('search.dataLoadError', 'Unable to load search records. Please try again later.'))
    });
  }

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  protected changeSearchType(event: Event): void {
    const routes: Record<string, string> = {
      paid: '/search/paid',
      issued: '/search/issued',
      issuedFiles: '/search/issued-files'
    };
    const route = routes[(event.target as HTMLSelectElement).value];
    if (route) {
      void this.router.navigateByUrl(route);
    }
  }

  protected search(form: HTMLFormElement): void {
    const data = new FormData(form);
    const value = (name: string): string => String(data.get(name) ?? '').trim();
    const criteria: IssuedFilesCriteria = {
      searchBy: this.searchBy(),
      startDate: this.searchBy() === 'fileDate' ? value('startDate') : '',
      endDate: this.searchBy() === 'fileDate' ? value('endDate') : '',
      issuedFileNumber: this.searchBy() === 'reference' ? value('issuedFileNumber').toLocaleLowerCase() : '',
      accounts: [...this.selectedAccounts()]
    };

    this.results.set(this.records().filter((record) => {
      return (!criteria.accounts.length || criteria.accounts.includes(record.account)) &&
        (criteria.searchBy === 'reference'
          ? (!criteria.issuedFileNumber || record.issuedFileNumber.toLocaleLowerCase() === criteria.issuedFileNumber)
          : (!criteria.startDate || record.issuedDate >= criteria.startDate) &&
            (!criteria.endDate || record.issuedDate <= criteria.endDate));
    }));
    this.deleteSelections.set({});
    this.page.set(1);
    this.submitted.set(true);
  }

  protected clear(form: HTMLFormElement): void {
    form.reset();
    this.selectedAccounts.set([]);
    this.searchBy.set('fileDate');
    this.startDate.set(this.defaultDate);
    this.endDate.set(this.defaultDate);
    this.deleteSelections.set({});
    this.results.set([]);
    this.page.set(1);
    this.submitted.set(false);
    this.accountMenuOpen.set(false);
  }

  protected toggleAccountMenu(): void {
    this.accountMenuOpen.update((open) => !open);
  }

  protected changeSearchBy(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.searchBy.set(value === 'reference' ? 'reference' : 'fileDate');
  }

  protected toggleAccount(account: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedAccounts.update((selected) => checked
      ? [...selected, account]
      : selected.filter((item) => item !== account));
  }

  protected isAccountSelected(account: string): boolean {
    return this.selectedAccounts().includes(account);
  }

  protected isAllAccountsSelected(): boolean {
    return this.selectedAccounts().length === this.accountOptions.length;
  }

  protected toggleAllAccounts(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.selectedAccounts.set(checked ? this.accountOptions.map((account) => account.value) : []);
  }

  protected getSelectedAccounts(): typeof this.accountOptions {
    return this.accountOptions.filter((account) => this.selectedAccounts().includes(account.value));
  }

  protected removeAccount(account: string): void {
    this.selectedAccounts.update((selected) => selected.filter((item) => item !== account));
  }

  protected updateDate(which: 'start' | 'end', event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    (which === 'start' ? this.startDate : this.endDate).set(value);
  }

  protected getVisibleFileGroups(): IssuedFilesGroup[] {
    const groups = this.getFileGroups();
    const start = (this.page() - 1) * this.pageSize;
    return groups.slice(start, start + this.pageSize);
  }

  private getFileGroups(): IssuedFilesGroup[] {
    const groups = new Map<string, IssuedFilesSearchRecord[]>();
    for (const record of this.results()) {
      const key = `${record.issuedFileNumber}|${record.account}`;
      const records = groups.get(key) ?? [];
      records.push(record);
      groups.set(key, records);
    }

    return [...groups.entries()].map(([key, records]) => ({
      key,
      customer: records[0].customer,
      account: records[0].account,
      issuedDate: records[0].issuedDate,
      issuedFileNumber: records[0].issuedFileNumber,
      statusRows: this.statusOptions.map(({ value, label }) => {
        const statusRecords = records.filter((record) => record.status.toLocaleLowerCase() === value);
        return {
          key: `${key}|${value}`,
          status: label,
          count: statusRecords.length,
          amount: statusRecords.reduce((total, record) => total + record.amount, 0)
        };
      })
    }));
  }

  protected isDeleteSelected(key: string): boolean {
    return this.deleteSelections()[key] ?? false;
  }

  protected setDeleteSelected(key: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.deleteSelections.update((selections) => ({ ...selections, [key]: checked }));
  }

  protected getPageCount(): number {
    return Math.max(1, Math.ceil(this.getFileGroups().length / this.pageSize));
  }

  protected getResultSummary(): string {
    const total = this.getFileGroups().length;
    if (!total) {
      return this.t('search.resultsSummaryEmpty', 'Total results found matching your search criteria: 0');
    }

    const first = (this.page() - 1) * this.pageSize + 1;
    const last = Math.min(first + this.pageSize - 1, total);
    return this.t('search.resultsSummary', 'Total results found matching your search criteria: {first} - {last} of {total}')
      .replace('{first}', String(first))
      .replace('{last}', String(last))
      .replace('{total}', String(total));
  }

  protected previousPage(): void {
    this.page.update((page) => Math.max(1, page - 1));
  }

  protected nextPage(): void {
    this.page.update((page) => Math.min(this.getPageCount(), page + 1));
  }
}
