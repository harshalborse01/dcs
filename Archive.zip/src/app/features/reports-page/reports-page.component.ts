import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-reports-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section class="reports-page">
      <h1>Generate Customer Reports</h1>

      <form class="customer-report-form" aria-label="Generate Customer Reports form">
        <div class="field-group">
          <label>Customer:</label>
          <input type="text" value="" aria-label="Customer" />
        </div>

        <div class="field-group">
          <label>Transit/Account:</label>
          <select aria-label="Transit Account">
            <option selected>Select Accounts</option>
            <option>Account 001</option>
            <option>Account 002</option>
            <option>Account 003</option>
          </select>
        </div>

        <div class="field-group report-type-group">
          <label>Report Type:</label>
          <select class="report-type-select" aria-label="Report Type">
            <option selected>Item Trace</option>
            <option>Paid</option>
            <option>Adjustments</option>
            <option>Return</option>
            <option>Deleted</option>
            <option>Negative Pay Serial Corrected</option>
            <option>Item Audit Log</option>
            <option>Account and Customer Audit Log</option>
          </select>
        </div>

        <div class="field-group date-field-group">
          <label>Date Range From:</label>
          <div class="date-wrap">
            <input type="date" value="2026-10-12" aria-label="Date range from" />
          </div>
        </div>

        <div class="field-group to-field">
          <label>To:</label>
          <div class="date-wrap">
            <input type="date" value="2026-10-12" aria-label="Date range to" />
          </div>
        </div>

        <button type="button" class="generate-button">Generate Report</button>
      </form>
    </section>
  `,
  styles: `
    :host {
      display: block;
      width: 100%;
      min-height: 100%;
    }

    .reports-page {
      min-height: 100%;
      padding-top: 0.45rem;
      background: transparent;
    }

    h1 {
      margin: 0 0 1.2rem;
      color: #000;
  font-size: 24px;
  font-weight: 700;
      letter-spacing: -0.04em;
    }

    .customer-report-form {
      width: min(100%, 330px);
      max-height: 77vh !important;
    padding: 30px 20px;
    border: 1px solid var(--color-border);
    }

    .field-group {
      display: flex;
      flex-direction: column;
      gap: 0.32rem;
      margin-bottom: 0.8rem;
    }

    .field-group label {
      color: rgba(60, 65, 70, 0.9);
      font-size: 0.72rem;
      font-weight: 500;
      line-height: 1.25;
      letter-spacing: 0.01em;
    }

    input,
    select {
      width: 100%;
      height: 2rem;
      border: 1px solid rgba(138, 145, 150, 0.82);
      border-radius: 3px;
      background: rgba(255, 255, 255, 0.08);
      color: rgba(41, 46, 50, 0.85);
      font-size: 0.75rem;
      padding: 0.35rem 0.75rem;
      box-sizing: border-box;
      outline: none;
    }

    input:focus,
    select:focus {
      border-color: rgba(0, 121, 184, 0.8);
      box-shadow: 0 0 0 2px rgba(0, 121, 184, 0.12);
    }

    select {
      appearance: none;
      background-image: linear-gradient(45deg, transparent 50%, rgba(80, 85, 90, 0.85) 50%),
        linear-gradient(135deg, rgba(80, 85, 90, 0.85) 50%, transparent 50%);
      background-position: calc(100% - 16px) calc(50% - 2px), calc(100% - 11px) calc(50% - 2px);
      background-size: 5px 5px, 5px 5px;
      background-repeat: no-repeat;
      padding-right: 2rem;
    }

    .report-type-select {
      height: 2.2rem;
      border-width: 2px;
      border-color: rgba(72, 80, 87, 0.9);
      background-color: rgba(255, 255, 255, 0.05);
      font-size: 0.78rem;
    }

    .date-wrap {
      position: relative;
    }

    .date-wrap input {
      padding-right: 1.9rem;
      color: rgba(51, 58, 62, 0.9);
    }

    input[type='date'] {
      appearance: none;
      -webkit-appearance: none;
      min-height: 2rem;
      position: relative;
    }

    input[type='date']::-webkit-calendar-picker-indicator {
      opacity: 1;
      cursor: pointer;
      filter: invert(0.45);
      width: 14px;
      height: 14px;
      margin-right: -4px;
    }

    .to-field {
      margin-top: 0.3rem;
    }

    .generate-button {
      width: 100%;
      height: 2.35rem;
      margin-top: 0.4rem;
      border: 0;
      border-radius: 4px;
      background: #0ea7d9;
      color: #fff;
      font-size: 0.74rem;
      font-weight: 600;
      letter-spacing: 0.01em;
      cursor: pointer;
      box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.12);
    }

    .generate-button:hover,
    .generate-button:focus-visible {
      filter: brightness(0.98);
      outline: none;
    }

    @media (max-width: 700px) {
      .customer-report-form {
        width: 100%;
      }
    }
  `
})
export class ReportsPageComponent {}
