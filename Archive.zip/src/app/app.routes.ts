import { Routes } from '@angular/router';
import { ExceptionsComponent } from './features/exceptions/exceptions.component';
import { HomeComponent } from './features/home/home.component';
import { NotFoundComponent } from './features/not-found/not-found.component';
import { ReportsPageComponent } from './features/reports-page/reports-page.component';
import { SearchPageComponent } from './features/search-page/search-page.component';
import { UploadsComponent } from './features/uploads/uploads.component';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'exceptions', component: ExceptionsComponent },
  { path: 'search', component: SearchPageComponent },
  { path: 'reports', component: ReportsPageComponent },
  { path: 'uploads', component: UploadsComponent },
  { path: '**', component: NotFoundComponent }
];
