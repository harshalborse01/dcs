import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { MockDataService, ReportItem } from '../../core/services/mock-data.service';
import { TranslationService } from '../../core/services/translation.service';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {
  protected readonly reports = signal<ReportItem[]>([]);

  constructor(
    private readonly mockDataService: MockDataService,
    private readonly translationService: TranslationService
  ) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  ngOnInit(): void {
    this.mockDataService.getReports().subscribe((items) => this.reports.set(items));
  }
}
