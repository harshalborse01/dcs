import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { TranslationService } from '../../core/services/translation.service';

type ReportRetrievalColumn = {
  key: string;
  label: string;
  sortable?: boolean;
};

type ReportRetrievalRow = {
  requestNumber: string;
  requestDateTime: string;
  customer: string;
  account: string;
  reportType: string;
  fileName: string;
  requestExpiry: string;
  status: string;
};

type ReportRetrievalData = {
  title: string;
  note: {
    message: string;
    count: number;
  };
  columns: ReportRetrievalColumn[];
  rows: ReportRetrievalRow[];
  summary: {
    label: string;
    value: string;
    count: string;
  };
};

@Component({
  selector: 'app-report-retrieval',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './report-retrieval.component.html',
  styleUrls: ['./report-retrieval.component.scss']
})
export class ReportRetrievalComponent implements OnInit {
  protected readonly retrievalData = signal<ReportRetrievalData | null>(null);

  constructor(private readonly translationService: TranslationService) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  protected translateFieldValue(field: string, value: string): string {
    const map: Record<string, Record<string, string>> = {
      status: {
        Completed: 'reportRetrieval.status.completed',
        Pending: 'reportRetrieval.status.pending',
        Ready: 'reportRetrieval.status.ready'
      },
      reportType: {
        Paid: 'reportRetrieval.reportType.paid',
        Stops: 'reportRetrieval.reportType.stops',
        'Stops and Voids': 'reportRetrieval.reportType.stopsAndVoids'
      },
      column: {
        'Request #': 'reportRetrieval.columns.requestNumber',
        'Request Date & Time': 'reportRetrieval.columns.requestDateTime',
        Customer: 'reportRetrieval.columns.customer',
        Account: 'reportRetrieval.columns.account',
        ReportType: 'reportRetrieval.columns.reportType',
        'File Name': 'reportRetrieval.columns.fileName',
        'Request Expiry': 'reportRetrieval.columns.requestExpiry',
        Status: 'reportRetrieval.columns.status'
      }
    };

    const lookup = map[field]?.[value];
    return lookup ? this.t(lookup, value) : value;
  }

  protected getPageTitle(title: string): string {
    return this.t('reportRetrieval.pageTitle', title);
  }

  protected getNoteMessage(message: string): string {
    return this.t('reportRetrieval.note', message);
  }

  protected getColumnLabel(column: ReportRetrievalColumn): string {
    return this.t(
      `reportRetrieval.columns.${column.key}`,
      this.translateFieldValue('column', column.label)
    );
  }

  protected getSummaryLabel(label: string): string {
    return this.t('reportRetrieval.summary.label', label);
  }

  ngOnInit(): void {
    fetch('/assets/mock-data/reports.json')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Unable to load report mock data');
        }

        return response.json() as Promise<{ reportRetrieval?: ReportRetrievalData }>;
      })
      .then((payload) => {
        const baseData = payload.reportRetrieval ?? null;
        if (!baseData) {
          this.retrievalData.set(null);
          return;
        }

        const generatedRows = this.readGeneratedRows();
        const mergedRows = [...baseData.rows, ...generatedRows];

        this.retrievalData.set({
          ...baseData,
          rows: mergedRows,
          note: {
            ...baseData.note,
            count: mergedRows.length
          },
          summary: {
            ...baseData.summary,
            value: `${mergedRows.length} total`,
            count: String(mergedRows.length)
          }
        });
      })
      .catch((error) => {
        console.error('Failed to load report retrieval data', error);
        this.retrievalData.set(null);
      });
  }

  private readGeneratedRows(): ReportRetrievalRow[] {
    try {
      const stored = localStorage.getItem('report-retrieval-generated-rows');
      if (!stored) {
        return [];
      }

      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
}
