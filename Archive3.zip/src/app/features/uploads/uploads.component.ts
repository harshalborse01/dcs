import { Component } from '@angular/core';
import { TranslationService } from '../../core/services/translation.service';

@Component({
  selector: 'app-uploads',
  standalone: true,
  templateUrl: './uploads.component.html',
  styleUrls: ['./uploads.component.scss']
})
export class UploadsComponent {
  constructor(private readonly translationService: TranslationService) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }
}
