import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MockDataService, SearchRecord } from '../../core/services/mock-data.service';
import { TranslationService } from '../../core/services/translation.service';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  protected query = '';
  protected readonly records = signal<SearchRecord[]>([]);
  protected readonly filteredRecords = signal<SearchRecord[]>([]);

  constructor(
    private readonly mockDataService: MockDataService,
    private readonly translationService: TranslationService
  ) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  ngOnInit(): void {
    this.mockDataService.getSearchResults().subscribe((records) => {
      this.records.set(records);
      this.filteredRecords.set(records);
    });
  }

  applyFilter(): void {
    const value = this.query.trim().toLowerCase();
    const nextRecords = value
      ? this.records().filter((record) =>
          `${record.title} ${record.category} ${record.description}`.toLowerCase().includes(value)
        )
      : this.records();

    this.filteredRecords.set(nextRecords);
  }
}
