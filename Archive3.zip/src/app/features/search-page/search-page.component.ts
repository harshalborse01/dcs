import { Component } from '@angular/core';
import { TranslationService } from '../../core/services/translation.service';

@Component({
  selector: 'app-search-page',
  standalone: true,
  templateUrl: './search-page.component.html',
  styleUrls: ['./search-page.component.scss']
})
export class SearchPageComponent {
  constructor(private readonly translationService: TranslationService) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }
}
