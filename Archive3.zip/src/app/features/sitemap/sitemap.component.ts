import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { TranslationService } from '../../core/services/translation.service';

@Component({
  selector: 'app-sitemap',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './sitemap.component.html',
  styleUrls: ['./sitemap.component.scss']
})
export class SitemapComponent {
  constructor(private readonly translationService: TranslationService) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }
}
