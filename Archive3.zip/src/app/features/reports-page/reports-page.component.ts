import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { TranslationService } from '../../core/services/translation.service';

@Component({
  selector: 'app-reports-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './reports-page.component.html',
  styleUrls: ['./reports-page.component.scss']
})
export class ReportsPageComponent {
  protected readonly bannerType = signal<'success' | 'error' | 'none'>('none');
  protected readonly validationMessages = signal<string[]>([]);

  constructor(private readonly translationService: TranslationService) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }
  protected readonly selectedAccounts = signal<string[]>([]);
  protected readonly isAccountsDropdownOpen = signal(false);
  protected readonly accountOptions = [
    { label: 'Account 001', value: 'Account 001' },
    { label: 'Account 002', value: 'Account 002' },
    { label: 'Account 003', value: 'Account 003' }
  ];

  protected toggleAccountsDropdown(): void {
    this.isAccountsDropdownOpen.update((value) => !value);
  }

  protected isAccountSelected(accountValue: string): boolean {
    return this.selectedAccounts().includes(accountValue);
  }

  protected isSelectAllSelected(): boolean {
    return this.selectedAccounts().length === this.accountOptions.length;
  }

  protected toggleAccount(accountValue: string, event: Event): void {
    const target = event.target as HTMLInputElement;
    const current = this.selectedAccounts();

    if (target.checked) {
      this.selectedAccounts.set([...current, accountValue]);
      return;
    }

    this.selectedAccounts.set(current.filter((value) => value !== accountValue));
  }

  protected toggleSelectAll(event: Event): void {
    const target = event.target as HTMLInputElement;

    if (target.checked) {
      this.selectedAccounts.set(this.accountOptions.map((account) => account.value));
      return;
    }

    this.selectedAccounts.set([]);
  }

  protected generateReport(): void {
    const transit = this.selectedAccounts();
    const reportType = (document.querySelector('[aria-label="Report Type"]') as HTMLSelectElement | null)?.value ?? '';
    const dateFrom = (document.querySelector('[aria-label="Date range from"]') as HTMLInputElement | null)?.value ?? '';
    const dateTo = (document.querySelector('[aria-label="Date range to"]') as HTMLInputElement | null)?.value ?? '';

    const missingFields: { key: string; label: string }[] = [];

    if (!transit.length) {
      missingFields.push({ key: 'reportPage.missingTransit', label: this.t('reportsPage.transitAccount', 'Transit/Account') });
    }

    if (!reportType || reportType === this.t('common.pleaseSelect', 'Please select')) {
      missingFields.push({ key: 'reportPage.missingReportType', label: this.t('reportsPage.reportType', 'Report Type') });
    }

    if (!dateFrom) {
      missingFields.push({ key: 'reportPage.missingDateFrom', label: this.t('reportsPage.dateFrom', 'Date Range From') });
    }

    if (!dateTo) {
      missingFields.push({ key: 'reportPage.missingTo', label: this.t('reportsPage.to', 'To') });
    }

    if (missingFields.length > 0) {
      this.validationMessages.set(
        missingFields.map((field) => this.t('common.pleaseSelectA', `Please select a ${field.label}.`).replace('{label}', field.label))
      );
      this.bannerType.set('error');
      return;
    }

    const now = new Date();
    const requestNumber = String(Math.floor(1000000 + Math.random() * 9000000)).padStart(7, '0');
    const requestDateTime = `${now.toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric'
    })} ${now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    })} EDT`;

    const generatedEntry = {
      requestNumber,
      requestDateTime,
      customer: 'Demo User',
      account: transit.length ? transit.join(', ') : 'All Accounts',
      reportType: reportType || 'Unknown Report',
      fileName: `${(reportType || 'report').toLowerCase().replace(/\s+/g, '-')}.csv`,
      requestExpiry: new Date(Date.now() + 86400000).toLocaleDateString('en-US', {
        month: '2-digit',
        day: '2-digit',
        year: 'numeric'
      }),
      status: 'Completed'
    };

    const persistedRows = this.readGeneratedRows();
    const nextRows = [...persistedRows, generatedEntry];
    localStorage.setItem('report-retrieval-generated-rows', JSON.stringify(nextRows));

    this.selectedAccounts.set([]);
    this.validationMessages.set([]);
    this.bannerType.set('success');
  }

  protected dismissBanner(): void {
    this.bannerType.set('none');
    this.validationMessages.set([]);
  }

  private readGeneratedRows(): Array<Record<string, string>> {
    try {
      const stored = localStorage.getItem('report-retrieval-generated-rows');
      if (!stored) {
        return [];
      }

      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
}
