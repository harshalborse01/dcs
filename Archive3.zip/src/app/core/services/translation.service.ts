import { Injectable, signal } from '@angular/core';

export type SupportedLanguage = 'en' | 'fr';

@Injectable({ providedIn: 'root' })
export class TranslationService {
  private readonly storageKey = 'app-language';
  private readonly translations = signal<Record<string, string>>({});
  readonly currentLanguage = signal<SupportedLanguage>('en');

  constructor() {
    const savedLanguage = localStorage.getItem(this.storageKey) as SupportedLanguage | null;
    const initialLanguage = savedLanguage === 'fr' ? 'fr' : 'en';
    void this.setLanguage(initialLanguage, false);
  }

  async setLanguage(language: SupportedLanguage, persist = true): Promise<void> {
    this.currentLanguage.set(language);

    if (persist) {
      localStorage.setItem(this.storageKey, language);
    }

    const response = await fetch(`/assets/i18n/${language}.json`, { cache: 'no-store' });

    if (!response.ok) {
      throw new Error(`Unable to load translations for ${language}`);
    }

    const payload = (await response.json()) as Record<string, string>;
    this.translations.set(payload);
  }

  t(key: string, fallback = key): string {
    return this.translations()[key] ?? fallback;
  }
}
