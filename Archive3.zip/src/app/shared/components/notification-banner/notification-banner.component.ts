import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { MockDataService, NotificationMessage } from '../../../core/services/mock-data.service';
import { TranslationService } from '../../../core/services/translation.service';

@Component({
  selector: 'app-notification-banner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './notification-banner.component.html',
  styleUrls: ['./notification-banner.component.scss']
})
export class NotificationBannerComponent implements OnInit {
  protected readonly notificationItems = signal<NotificationMessage[]>([]);
  protected dismissed = false;

  constructor(
    private readonly mockDataService: MockDataService,
    private readonly translationService: TranslationService
  ) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  protected translateMessage(message: string): string {
    const map: Record<string, string> = {
      'One or more transit/account(s) is inaccessible: undefined:, please contact your Administrator.':
        'notification.transitUndefined',
      'One or more transit/account(s) is inaccessible: No Account, please contact your Administrator.':
        'notification.transitNoAccount'
    };

    return this.translationService.t(map[message] ?? message, message);
  }

  ngOnInit(): void {
    this.mockDataService.getNotifications().subscribe((data) => this.notificationItems.set(data.items));
  }

  dismiss(): void {
    this.dismissed = true;
  }
}
