import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MockDataService, NavigationCardItem } from '../../../core/services/mock-data.service';
import { TranslationService } from '../../../core/services/translation.service';

@Component({
  selector: 'app-left-navigation',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './left-navigation.component.html',
  styleUrls: ['./left-navigation.component.scss']
})
export class LeftNavigationComponent implements OnInit {
  protected readonly navigationItems = signal<NavigationCardItem[]>([]);

  constructor(
    private readonly mockDataService: MockDataService,
    private readonly translationService: TranslationService
  ) {}

  protected t(key: string, fallback = key): string {
    return this.translationService.t(key, fallback);
  }

  protected translateItemLabel(item: NavigationCardItem): string {
    const map: Record<string, string> = {
      '/exceptions': 'nav.exceptions',
      '/search': 'nav.search',
      '/reports': 'nav.reports',
      '/uploads': 'nav.uploads'
    };

    return this.translationService.t(map[item.route] ?? item.label, item.label);
  }

  ngOnInit(): void {
    this.mockDataService.getNavigationCards().subscribe((items) => this.navigationItems.set(items));
  }
}
